<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc08864f41             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Helper; use Pmpr\Common\Foundation\Traits\InstanceTrait; class Helper extends Common { use InstanceTrait; public function gagsyqagguwwauac() : I18N { return $this->ggmimykuacwcogaq(I18N::class); } public function eioauiqeyweiokag() : Purge { return $this->ggmimykuacwcogaq(Purge::class); } public function asgqmkcukouykiie() : Tool { return $this->ggmimykuacwcogaq(Tool::class); } }
