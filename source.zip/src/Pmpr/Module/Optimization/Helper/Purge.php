<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dbbdd6ed73f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Helper; use Pmpr\Common\Foundation\Interfaces\Constants; class Purge extends Common { public function ckuaeyecaekkkwqs($post = null) : bool { $macmssugksugukws = [Constants::ywskismomwmcsqam, Constants::scwmgoegsukauoku, Constants::cssaaweyquokqaeq, Constants::aqugcqsyeisayuog, Constants::sgoswgskyiiwkyuo]; $iueymcwwscwqkiyq = $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->ucwmcwqmqwaymkkc($post); if (in_array($iueymcwwscwqkiyq, $macmssugksugukws, true)) { return false; } $gcgsqcoqciockquc = $this->uwkmaywceaaaigwo()->ogciwyoqgciosgcw()->oequuauskyumwyau(); return !($gcgsqcoqciockquc && Constants::ukwaycqmyyuekwqg === $gcgsqcoqciockquc->action); } }
