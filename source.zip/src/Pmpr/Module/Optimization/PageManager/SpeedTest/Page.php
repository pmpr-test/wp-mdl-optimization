<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758102f55148             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\SpeedTest; use Pmpr\Common\Foundation\Backend\Page as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Page extends BaseClass { public function qiccuiwooiquycsg() { $this->eukmukacucooequu([Constants::kekcgssiyagioocg => 5, Constants::wuowaiyouwecckaw => "\x70\x72\x5f\x6f\160\x74\137\x73\160\x65\x65\x64\137\164\145\163\164", Constants::ysgwugcqguggmigq => __("\105\154\145\143\164\145\x64\x20\120\x61\x67\x65\x73\47\163\40\123\x70\145\x65\144", PR__MDL__OPTIMIZATION), Constants::qoquaeuooeycomks => $this->caokeucsksukesyo()->cqusmgskowmesgcg()->aakmagwggmkoiiyu($this)]); } }
