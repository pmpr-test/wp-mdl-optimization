<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757fa6601788             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\SpeedTest; use Pmpr\Common\Foundation\Backend\Page as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Page extends BaseClass { public function qiccuiwooiquycsg() { $this->eukmukacucooequu([Constants::kekcgssiyagioocg => 5, Constants::wuowaiyouwecckaw => "\x70\162\x5f\x6f\160\164\137\x73\x70\x65\x65\x64\x5f\164\145\163\164", Constants::ysgwugcqguggmigq => __("\x45\x6c\x65\x63\x74\145\x64\40\x50\141\147\x65\x73\47\163\40\x53\160\145\145\144", PR__MDL__OPTIMIZATION), Constants::qoquaeuooeycomks => $this->caokeucsksukesyo()->cqusmgskowmesgcg()->aakmagwggmkoiiyu($this)]); } }
