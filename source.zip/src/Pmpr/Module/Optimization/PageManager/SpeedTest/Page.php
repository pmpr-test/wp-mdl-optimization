<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc08864f41             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\SpeedTest; use Pmpr\Common\Foundation\Backend\Page as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Page extends BaseClass { public function qiccuiwooiquycsg() { $this->eukmukacucooequu([Constants::kekcgssiyagioocg => 5, Constants::wuowaiyouwecckaw => "\x70\x72\137\157\160\x74\x5f\163\x70\145\145\144\137\x74\x65\163\x74", Constants::ysgwugcqguggmigq => __("\x45\154\x65\x63\x74\145\x64\x20\x50\141\x67\145\163\x27\x73\x20\123\x70\145\x65\144", PR__MDL__OPTIMIZATION), Constants::qoquaeuooeycomks => $this->caokeucsksukesyo()->cqusmgskowmesgcg()->aakmagwggmkoiiyu($this)]); } }
