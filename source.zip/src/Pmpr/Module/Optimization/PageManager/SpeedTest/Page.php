<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e823d067d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\SpeedTest; use Pmpr\Common\Foundation\Backend\Page as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Page extends BaseClass { public function qiccuiwooiquycsg() { $this->eukmukacucooequu([Constants::kekcgssiyagioocg => 5, Constants::wuowaiyouwecckaw => "\x6f\160\164\137\163\x70\x65\x65\x64\x5f\x74\x65\x73\164", Constants::ysgwugcqguggmigq => __("\105\154\145\143\164\145\x64\40\120\x61\x67\x65\163\x27\163\40\123\160\x65\145\x64", PR__MDL__OPTIMIZATION), Constants::qoquaeuooeycomks => $this->akuociswqmoigkas()]); } }
