<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb16d680906             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\SpeedTest; use Pmpr\Common\Foundation\Backend\Page as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Page extends BaseClass { public function qiccuiwooiquycsg() { $this->eukmukacucooequu([Constants::kekcgssiyagioocg => 5, Constants::wuowaiyouwecckaw => "\157\x70\164\x5f\163\160\145\145\x64\137\x74\x65\163\164", Constants::ysgwugcqguggmigq => __("\105\154\145\143\x74\145\x64\40\x50\x61\x67\x65\163\47\163\40\123\x70\145\145\144", PR__MDL__OPTIMIZATION), Constants::qoquaeuooeycomks => $this->akuociswqmoigkas()]); } }
