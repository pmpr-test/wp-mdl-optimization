<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d8d7adaa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; use Pmpr\Common\Foundation\Interfaces\Constants; class Local extends Common { public function register() { $this->guiaswksukmgageq(__("\114\x6f\143\x61\154\40\x52\165\156", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\x4c\x6f\143\141\x6c\x20\x52\x75\156\163", PR__MDL__OPTIMIZATION)); parent::register(); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->cquokmemekqqywgi($this->caokeucsksukesyo()->skckwsgymkimyuwo()->yyuiuwgokmwioomq(Constants::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\x41\x63\164\x69\157\156", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, Constants::iwksyuwwwkucsisq, __("\120\162\x65\154\157\x61\x64", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(Constants::iwksyuwwwkucsisq)); } }
