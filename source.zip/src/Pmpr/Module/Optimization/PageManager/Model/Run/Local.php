<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581596084c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; use Pmpr\Common\Foundation\Interfaces\Constants; class Local extends Common { public function register() { $this->guiaswksukmgageq(__("\x4c\x6f\143\141\154\40\x52\165\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\x4c\x6f\x63\x61\x6c\40\122\165\156\x73", PR__MDL__OPTIMIZATION)); parent::register(); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->cquokmemekqqywgi($this->caokeucsksukesyo()->skckwsgymkimyuwo()->yyuiuwgokmwioomq(Constants::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\101\143\x74\x69\157\156", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, Constants::iwksyuwwwkucsisq, __("\120\162\x65\154\157\141\144", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(Constants::iwksyuwwwkucsisq)); } }
