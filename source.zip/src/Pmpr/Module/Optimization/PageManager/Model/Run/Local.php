<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d7b77183e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; use Pmpr\Common\Foundation\Interfaces\Constants; class Local extends Common { public function ckgmycmaukqgkosk() { $this->oyeskqayoscwciem()->guiaswksukmgageq(__("\x4c\157\x63\x61\154\x20\x52\x75\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\x4c\x6f\x63\x61\154\40\x52\165\x6e\x73", PR__MDL__OPTIMIZATION)); parent::ckgmycmaukqgkosk(); } public function ewaqwooqoqmcoomi() { parent::ewaqwooqoqmcoomi(); $this->cquokmemekqqywgi($this->yyuiuwgokmwioomq(Constants::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\101\143\164\151\x6f\x6e", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, Constants::iwksyuwwwkucsisq, __("\120\162\145\154\x6f\x61\x64", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(Constants::iwksyuwwwkucsisq)); } }
