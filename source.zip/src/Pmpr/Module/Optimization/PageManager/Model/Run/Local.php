<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581ccae80ff             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model\Run; use Pmpr\Common\Foundation\Interfaces\Constants; class Local extends Common { public function register() { $this->guiaswksukmgageq(__("\x4c\x6f\143\x61\154\x20\122\165\x6e", PR__MDL__OPTIMIZATION))->muuwuqssqkaieqge(__("\114\x6f\143\141\154\40\122\x75\x6e\x73", PR__MDL__OPTIMIZATION)); parent::register(); } public function uwmqacgewuauagai() { parent::uwmqacgewuauagai(); $this->cquokmemekqqywgi($this->caokeucsksukesyo()->skckwsgymkimyuwo()->yyuiuwgokmwioomq(Constants::uqgcmmosieyimiku)->acokiqqgsmoqaeyu()->gswweykyogmsyawy(__("\x41\143\164\x69\157\156", PR__MDL__OPTIMIZATION))->kesomeowemmyygey(1, Constants::iwksyuwwwkucsisq, __("\x50\162\145\x6c\157\141\144", PR__MDL__OPTIMIZATION))->eyygsasuqmommkua(Constants::iwksyuwwwkucsisq)); } }
