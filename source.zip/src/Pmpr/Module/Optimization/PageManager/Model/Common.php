<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e68d3d663             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\145\143\x69\141\154\137\x70\x61\147\145"; const wqqksssaoggqceky = "\x64\x69\163\143\162\151\155\151\x6e\x61\x74\x6f\x72"; const swkaqiikoaickuui = "\157\160\164\151\x6d\151\x7a\145"; const ccoesaeoiusskiew = "\x72\145\55\157\x70\x74\151\x6d\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\x72\x67\x65\137\156\157\x6e\x63\x65"; const hwawamsmicyywemy = "\143\141\x63\150\x65\x5f\x73\x74\141\x74\165\163"; }
