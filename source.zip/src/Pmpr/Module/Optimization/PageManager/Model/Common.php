<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1ea51a7c51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\143\151\141\x6c\137\x70\x61\x67\x65"; const wqqksssaoggqceky = "\x64\x69\163\143\162\151\x6d\151\x6e\141\x74\x6f\162"; const swkaqiikoaickuui = "\157\160\164\x69\155\151\x7a\145"; const ccoesaeoiusskiew = "\162\145\x2d\x6f\160\x74\151\x6d\x69\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\162\x67\145\x5f\x6e\x6f\x6e\x63\145"; const hwawamsmicyywemy = "\143\141\143\150\x65\x5f\x73\164\141\x74\x75\x73"; }
