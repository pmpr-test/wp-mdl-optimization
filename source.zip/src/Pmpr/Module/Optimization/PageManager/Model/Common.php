<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581596084c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\143\x69\x61\154\137\160\x61\147\145"; const wqqksssaoggqceky = "\144\x69\163\x63\x72\x69\x6d\151\156\141\x74\157\162"; const swkaqiikoaickuui = "\x6f\x70\x74\151\x6d\x69\172\x65"; const ccoesaeoiusskiew = "\162\145\55\157\160\x74\x69\x6d\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\162\x67\x65\x5f\x6e\157\156\143\145"; const hwawamsmicyywemy = "\143\141\143\150\145\137\163\164\141\164\165\163"; }
