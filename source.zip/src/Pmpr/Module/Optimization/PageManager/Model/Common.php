<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757fa6601788             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\143\151\141\154\x5f\x70\x61\147\145"; const wqqksssaoggqceky = "\x64\151\163\x63\x72\x69\155\151\156\141\164\157\162"; const swkaqiikoaickuui = "\x6f\x70\x74\x69\155\151\172\x65"; const ccoesaeoiusskiew = "\x72\x65\x2d\157\x70\x74\x69\155\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\x72\147\145\137\x6e\x6f\x6e\143\x65"; const hwawamsmicyywemy = "\143\141\143\150\x65\137\163\164\x61\164\165\163"; }
