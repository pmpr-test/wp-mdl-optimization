<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581d1ae35f7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\x63\x69\x61\x6c\137\x70\x61\147\145"; const wqqksssaoggqceky = "\144\151\x73\x63\162\x69\155\x69\x6e\x61\x74\x6f\162"; const swkaqiikoaickuui = "\157\x70\164\151\155\x69\x7a\x65"; const ccoesaeoiusskiew = "\x72\x65\x2d\157\x70\x74\x69\155\151\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\x72\147\145\137\x6e\x6f\156\143\145"; const hwawamsmicyywemy = "\143\x61\143\x68\x65\x5f\x73\x74\141\x74\165\x73"; }
