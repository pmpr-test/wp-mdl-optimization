<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758102f55148             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\x63\x69\141\154\137\160\x61\x67\145"; const wqqksssaoggqceky = "\x64\x69\x73\x63\162\151\x6d\151\156\x61\164\x6f\162"; const swkaqiikoaickuui = "\157\x70\164\151\x6d\x69\x7a\x65"; const ccoesaeoiusskiew = "\x72\145\x2d\x6f\160\164\x69\155\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\x72\147\145\137\x6e\157\x6e\143\145"; const hwawamsmicyywemy = "\143\141\143\150\145\x5f\163\164\x61\x74\x75\163"; }
