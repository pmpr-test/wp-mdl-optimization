<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d002186f7a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\x63\151\141\154\x5f\x70\x61\x67\x65"; const wqqksssaoggqceky = "\x64\x69\x73\x63\x72\x69\155\151\x6e\141\164\157\x72"; const swkaqiikoaickuui = "\x6f\x70\x74\x69\x6d\151\172\x65"; const ccoesaeoiusskiew = "\x72\x65\55\x6f\160\x74\x69\x6d\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\x72\x67\145\137\156\157\x6e\143\145"; const hwawamsmicyywemy = "\143\x61\x63\x68\145\137\x73\x74\141\x74\x75\x73"; }
