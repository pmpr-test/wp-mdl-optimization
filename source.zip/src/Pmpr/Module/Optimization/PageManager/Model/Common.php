<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f9e31abf5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\x63\151\x61\x6c\137\x70\x61\147\145"; const wqqksssaoggqceky = "\x64\x69\x73\143\162\151\x6d\x69\x6e\141\x74\157\162"; const swkaqiikoaickuui = "\x6f\160\x74\151\x6d\x69\172\145"; const ccoesaeoiusskiew = "\162\145\55\x6f\x70\164\x69\x6d\x69\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\162\147\x65\x5f\156\x6f\x6e\x63\x65"; const hwawamsmicyywemy = "\143\141\143\150\145\x5f\163\x74\141\164\x75\163"; }
