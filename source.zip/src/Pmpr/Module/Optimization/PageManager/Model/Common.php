<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68c2b5e775377             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = 'special_page'; const wqqksssaoggqceky = 'discriminator'; const swkaqiikoaickuui = 'optimize'; const ccoesaeoiusskiew = 're-optimize'; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . 'purge_nonce'; const hwawamsmicyywemy = 'cache_status'; }
