<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f1c30b6e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\145\x63\151\x61\154\x5f\x70\x61\147\145"; const wqqksssaoggqceky = "\x64\x69\x73\x63\x72\151\155\x69\156\141\x74\157\x72"; const swkaqiikoaickuui = "\x6f\x70\x74\x69\x6d\x69\x7a\x65"; const ccoesaeoiusskiew = "\162\x65\55\x6f\x70\164\151\155\151\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\162\x67\145\x5f\x6e\157\x6e\143\145"; const hwawamsmicyywemy = "\143\141\143\150\145\137\x73\x74\x61\x74\165\x73"; }
