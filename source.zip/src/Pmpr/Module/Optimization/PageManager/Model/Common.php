<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d8d7adaa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\x63\x69\x61\154\137\x70\141\x67\x65"; const wqqksssaoggqceky = "\144\151\163\143\162\151\x6d\x69\x6e\141\164\157\162"; const swkaqiikoaickuui = "\x6f\x70\164\151\155\151\172\x65"; const ccoesaeoiusskiew = "\162\x65\x2d\157\160\x74\151\x6d\x69\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\x67\x65\x5f\x6e\157\156\x63\145"; const hwawamsmicyywemy = "\x63\x61\x63\150\x65\x5f\x73\x74\141\164\165\x73"; }
