<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc08864f41             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\145\143\x69\x61\x6c\x5f\160\x61\x67\145"; const wqqksssaoggqceky = "\144\x69\163\x63\162\x69\155\x69\x6e\141\164\x6f\x72"; const swkaqiikoaickuui = "\x6f\160\x74\151\x6d\x69\x7a\145"; const ccoesaeoiusskiew = "\162\x65\55\157\x70\164\151\155\151\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\x67\x65\x5f\x6e\157\156\x63\145"; const hwawamsmicyywemy = "\x63\141\143\150\x65\137\x73\x74\x61\x74\x75\163"; }
