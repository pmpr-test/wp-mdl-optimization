<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67580826ed61d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\151\x61\154\137\x70\x61\147\145"; const wqqksssaoggqceky = "\x64\151\x73\x63\162\151\x6d\x69\156\x61\x74\157\x72"; const swkaqiikoaickuui = "\157\x70\x74\151\155\x69\x7a\x65"; const ccoesaeoiusskiew = "\x72\145\x2d\x6f\160\x74\151\155\x69\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\x72\x67\145\137\x6e\157\156\x63\x65"; const hwawamsmicyywemy = "\143\x61\143\150\145\x5f\x73\164\x61\164\165\163"; }
