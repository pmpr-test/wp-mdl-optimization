<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1342030351             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\x63\x69\141\x6c\137\160\x61\x67\145"; const wqqksssaoggqceky = "\144\x69\163\143\162\151\155\151\x6e\141\164\157\162"; const swkaqiikoaickuui = "\157\x70\x74\151\x6d\151\172\145"; const ccoesaeoiusskiew = "\162\145\x2d\157\160\164\x69\155\151\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\162\x67\x65\137\156\157\x6e\x63\145"; const hwawamsmicyywemy = "\x63\x61\x63\x68\x65\137\163\164\x61\x74\x75\x73"; }
