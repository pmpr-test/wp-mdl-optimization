<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08ff06dc0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\x63\151\141\154\x5f\160\141\147\145"; const mcewqquusaugsmmm = "\x73\160\145\x63\x69\x61\x6c\x5f\160\141\147\x65\x73"; const wqqksssaoggqceky = "\144\x69\163\x63\x72\x69\x6d\x69\156\x61\x74\x6f\162"; const swkaqiikoaickuui = "\157\160\x74\151\155\151\172\x65"; const ccoesaeoiusskiew = "\x72\x65\x2d\157\x70\164\151\155\151\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\x72\147\x65\137\x6e\157\156\143\145"; const hwawamsmicyywemy = "\x63\141\143\x68\145\137\163\x74\141\164\165\163"; }
