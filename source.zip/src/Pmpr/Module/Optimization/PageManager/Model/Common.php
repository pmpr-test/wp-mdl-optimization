<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15eb116f20             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\145\143\151\x61\x6c\x5f\x70\x61\147\145"; const wqqksssaoggqceky = "\144\x69\163\x63\162\151\x6d\x69\156\x61\164\x6f\162"; const swkaqiikoaickuui = "\x6f\x70\x74\151\155\x69\172\x65"; const ccoesaeoiusskiew = "\162\145\x2d\157\x70\164\x69\155\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\x72\147\145\x5f\156\157\x6e\143\145"; const hwawamsmicyywemy = "\x63\141\x63\150\x65\x5f\163\x74\x61\164\x75\163"; }
