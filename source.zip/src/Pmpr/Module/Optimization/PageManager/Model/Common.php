<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1377d8db9a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\x63\x69\141\x6c\x5f\x70\x61\147\x65"; const wqqksssaoggqceky = "\144\x69\x73\x63\162\x69\155\x69\156\141\164\x6f\162"; const swkaqiikoaickuui = "\157\x70\164\151\155\x69\x7a\145"; const ccoesaeoiusskiew = "\162\x65\55\157\160\x74\151\x6d\151\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\162\147\145\137\156\x6f\x6e\143\145"; const hwawamsmicyywemy = "\x63\141\143\x68\x65\x5f\x73\164\141\x74\x75\163"; }
