<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f18c2e9c9db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\x63\151\x61\x6c\137\x70\x61\x67\x65"; const wqqksssaoggqceky = "\x64\151\163\x63\162\x69\x6d\151\x6e\141\x74\x6f\162"; const swkaqiikoaickuui = "\x6f\x70\x74\151\x6d\151\172\x65"; const ccoesaeoiusskiew = "\x72\x65\x2d\x6f\x70\x74\x69\155\151\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\x72\x67\145\x5f\156\157\156\x63\x65"; const hwawamsmicyywemy = "\x63\141\143\150\145\137\x73\164\x61\164\x75\163"; }
