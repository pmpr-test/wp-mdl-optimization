<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a1764bb6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\x63\151\141\154\137\x70\x61\147\x65"; const wqqksssaoggqceky = "\144\x69\163\x63\162\x69\x6d\151\156\141\x74\x6f\162"; const swkaqiikoaickuui = "\x6f\x70\164\151\x6d\x69\x7a\145"; const ccoesaeoiusskiew = "\x72\145\x2d\x6f\160\x74\x69\x6d\151\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\162\147\x65\137\156\157\x6e\x63\x65"; const hwawamsmicyywemy = "\x63\x61\143\150\x65\137\x73\x74\x61\164\165\x73"; }
