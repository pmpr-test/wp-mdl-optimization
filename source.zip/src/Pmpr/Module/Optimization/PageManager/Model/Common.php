<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b5b18721             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\143\x69\141\154\137\160\141\147\145"; const wqqksssaoggqceky = "\x64\x69\x73\x63\162\x69\155\x69\156\141\x74\x6f\162"; const swkaqiikoaickuui = "\x6f\160\x74\x69\x6d\x69\172\145"; const ccoesaeoiusskiew = "\162\x65\x2d\x6f\x70\164\151\155\151\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\162\x67\x65\137\x6e\157\x6e\x63\x65"; const hwawamsmicyywemy = "\143\141\143\150\x65\137\163\164\141\x74\165\163"; }
