<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a60d5dfe2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\x63\x69\x61\154\x5f\x70\141\147\x65"; const wqqksssaoggqceky = "\x64\151\163\x63\162\151\x6d\151\x6e\x61\x74\x6f\x72"; const swkaqiikoaickuui = "\x6f\160\164\x69\x6d\x69\x7a\145"; const ccoesaeoiusskiew = "\x72\x65\55\x6f\x70\164\151\155\x69\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\162\x67\145\137\x6e\x6f\156\143\145"; const hwawamsmicyywemy = "\143\x61\x63\150\145\x5f\163\x74\141\x74\165\x73"; }
