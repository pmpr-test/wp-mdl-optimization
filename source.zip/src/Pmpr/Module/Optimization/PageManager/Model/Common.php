<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d980cb95de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\x63\x69\141\154\137\160\x61\x67\x65"; const wqqksssaoggqceky = "\x64\x69\x73\143\162\x69\155\151\x6e\x61\164\x6f\x72"; const swkaqiikoaickuui = "\x6f\x70\x74\151\155\x69\x7a\145"; const ccoesaeoiusskiew = "\x72\145\x2d\157\x70\164\151\155\x69\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\147\x65\137\x6e\157\156\x63\145"; const hwawamsmicyywemy = "\143\141\143\150\x65\x5f\x73\164\141\x74\165\x73"; }
