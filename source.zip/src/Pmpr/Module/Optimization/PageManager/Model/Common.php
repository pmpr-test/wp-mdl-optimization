<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a588a282a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\x63\x69\141\x6c\137\x70\141\147\x65"; const wqqksssaoggqceky = "\144\151\x73\x63\x72\x69\155\x69\156\141\164\157\x72"; const swkaqiikoaickuui = "\157\x70\164\x69\x6d\x69\172\x65"; const ccoesaeoiusskiew = "\162\145\55\157\160\164\151\155\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\x67\145\x5f\x6e\157\156\x63\145"; const hwawamsmicyywemy = "\143\x61\x63\x68\145\x5f\x73\164\x61\x74\x75\x73"; }
