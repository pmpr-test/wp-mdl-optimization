<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581ccae80ff             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\x63\x69\141\x6c\x5f\x70\x61\x67\x65"; const wqqksssaoggqceky = "\144\x69\163\x63\x72\x69\x6d\x69\x6e\141\x74\x6f\x72"; const swkaqiikoaickuui = "\157\x70\x74\x69\155\151\172\145"; const ccoesaeoiusskiew = "\162\x65\x2d\157\160\x74\151\x6d\x69\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\x72\147\x65\x5f\156\x6f\156\143\x65"; const hwawamsmicyywemy = "\x63\141\143\150\x65\x5f\163\x74\x61\x74\165\163"; }
