<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f18cb37259d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\x63\x69\141\x6c\x5f\160\x61\147\145"; const wqqksssaoggqceky = "\x64\x69\x73\x63\x72\x69\x6d\x69\x6e\141\164\x6f\x72"; const swkaqiikoaickuui = "\157\160\164\151\155\x69\x7a\145"; const ccoesaeoiusskiew = "\x72\x65\x2d\157\160\x74\x69\155\151\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\x72\x67\145\x5f\x6e\x6f\x6e\x63\145"; const hwawamsmicyywemy = "\143\141\x63\x68\x65\137\x73\x74\x61\x74\x75\x73"; }
