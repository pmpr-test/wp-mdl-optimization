<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76d1d04df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\x63\x69\x61\154\137\160\x61\x67\x65"; const wqqksssaoggqceky = "\x64\x69\163\143\x72\151\155\151\x6e\x61\x74\x6f\162"; const swkaqiikoaickuui = "\157\x70\x74\x69\x6d\x69\172\145"; const ccoesaeoiusskiew = "\x72\x65\x2d\157\160\164\151\155\x69\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\162\x67\145\x5f\x6e\157\156\143\x65"; const hwawamsmicyywemy = "\x63\141\x63\x68\145\x5f\163\164\x61\164\165\x73"; }
