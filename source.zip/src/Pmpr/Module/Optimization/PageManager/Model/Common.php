<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a3df79fb7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\143\x69\141\x6c\137\x70\141\147\x65"; const wqqksssaoggqceky = "\144\x69\163\x63\162\151\155\151\156\x61\164\x6f\x72"; const swkaqiikoaickuui = "\157\x70\164\x69\x6d\151\x7a\145"; const ccoesaeoiusskiew = "\x72\145\55\157\x70\x74\x69\155\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\162\147\x65\x5f\x6e\x6f\x6e\x63\145"; const hwawamsmicyywemy = "\x63\141\x63\150\145\137\x73\x74\x61\x74\x75\163"; }
