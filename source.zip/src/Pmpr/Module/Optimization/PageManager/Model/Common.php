<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723572e2b020             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\x63\151\141\154\137\x70\141\x67\145"; const wqqksssaoggqceky = "\x64\x69\163\x63\162\151\x6d\151\156\x61\x74\157\162"; const swkaqiikoaickuui = "\157\160\x74\x69\155\151\172\x65"; const ccoesaeoiusskiew = "\x72\x65\55\x6f\160\164\151\x6d\x69\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\x72\147\x65\x5f\156\x6f\156\143\x65"; const hwawamsmicyywemy = "\x63\141\143\x68\x65\x5f\163\164\141\x74\x75\x73"; }
