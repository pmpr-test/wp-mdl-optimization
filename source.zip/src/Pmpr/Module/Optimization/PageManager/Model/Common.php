<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd9008d45             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\x65\143\x69\141\154\137\x70\x61\147\145"; const wqqksssaoggqceky = "\144\x69\163\143\162\151\x6d\151\156\141\x74\157\x72"; const swkaqiikoaickuui = "\x6f\160\x74\x69\x6d\151\x7a\x65"; const ccoesaeoiusskiew = "\x72\145\55\x6f\160\164\151\x6d\151\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\x67\x65\x5f\x6e\157\156\143\x65"; const hwawamsmicyywemy = "\143\141\x63\x68\x65\x5f\163\x74\x61\x74\165\163"; }
