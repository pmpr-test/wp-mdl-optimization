<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f0cc89158             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\143\x69\141\x6c\x5f\x70\141\147\145"; const wqqksssaoggqceky = "\144\x69\x73\x63\x72\151\155\x69\156\141\x74\157\162"; const swkaqiikoaickuui = "\157\160\x74\x69\155\151\172\145"; const ccoesaeoiusskiew = "\162\145\x2d\157\160\x74\x69\x6d\151\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\x72\x67\x65\137\x6e\157\x6e\x63\145"; const hwawamsmicyywemy = "\143\x61\x63\150\x65\x5f\163\x74\x61\x74\165\163"; }
