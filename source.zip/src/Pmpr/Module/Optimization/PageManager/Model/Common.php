<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16a50f1e99             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\x65\x63\x69\141\x6c\137\x70\x61\x67\x65"; const wqqksssaoggqceky = "\x64\x69\x73\143\162\x69\155\151\156\x61\x74\157\162"; const swkaqiikoaickuui = "\157\x70\164\x69\155\151\172\145"; const ccoesaeoiusskiew = "\x72\x65\55\157\x70\x74\151\155\x69\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\162\x67\145\x5f\x6e\x6f\156\143\x65"; const hwawamsmicyywemy = "\x63\141\x63\150\145\x5f\163\164\x61\x74\x75\163"; }
