<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e823d067d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\143\x69\x61\154\137\160\x61\147\145"; const mcewqquusaugsmmm = "\x73\x70\x65\143\x69\141\x6c\137\160\141\147\145\163"; const wqqksssaoggqceky = "\x64\151\163\143\x72\151\155\151\x6e\x61\x74\157\x72"; const swkaqiikoaickuui = "\157\x70\x74\x69\155\151\172\145"; const ccoesaeoiusskiew = "\x72\x65\x2d\x6f\x70\x74\x69\155\151\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\x72\x67\x65\x5f\156\157\156\x63\145"; const hwawamsmicyywemy = "\x63\141\143\x68\145\x5f\163\x74\x61\164\165\163"; }
