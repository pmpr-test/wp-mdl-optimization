<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4dfc43710             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\143\x69\x61\x6c\137\160\141\147\145"; const mcewqquusaugsmmm = "\163\160\x65\143\x69\141\154\x5f\x70\141\x67\x65\163"; const wqqksssaoggqceky = "\x64\151\163\143\162\x69\x6d\151\x6e\141\x74\x6f\162"; const swkaqiikoaickuui = "\x6f\x70\x74\151\x6d\151\172\145"; const ccoesaeoiusskiew = "\162\145\x2d\157\x70\x74\151\x6d\x69\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\162\147\145\137\x6e\157\x6e\x63\145"; const hwawamsmicyywemy = "\x63\x61\x63\150\x65\137\x73\164\141\x74\165\x73"; }
