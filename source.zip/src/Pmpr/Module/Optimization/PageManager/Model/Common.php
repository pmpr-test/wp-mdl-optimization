<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b73d10da1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\143\151\x61\154\137\x70\x61\147\x65"; const wqqksssaoggqceky = "\144\151\163\143\x72\x69\155\x69\x6e\141\x74\x6f\162"; const swkaqiikoaickuui = "\157\x70\164\151\155\151\x7a\145"; const ccoesaeoiusskiew = "\162\x65\55\157\x70\x74\151\155\151\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\x72\x67\145\137\156\157\x6e\x63\145"; const hwawamsmicyywemy = "\x63\141\143\x68\x65\137\x73\x74\x61\x74\x75\163"; }
