<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c4541eb2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\145\143\151\141\x6c\x5f\160\x61\x67\145"; const wqqksssaoggqceky = "\144\151\163\x63\162\x69\x6d\x69\x6e\141\164\157\x72"; const swkaqiikoaickuui = "\x6f\160\x74\151\x6d\151\172\145"; const ccoesaeoiusskiew = "\162\145\55\x6f\x70\x74\151\x6d\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\x72\147\x65\x5f\156\157\x6e\143\x65"; const hwawamsmicyywemy = "\x63\x61\x63\150\x65\x5f\163\x74\x61\164\165\163"; }
