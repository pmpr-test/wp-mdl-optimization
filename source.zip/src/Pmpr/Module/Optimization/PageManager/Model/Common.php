<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0c9956f5c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\x63\x69\x61\x6c\137\x70\141\x67\x65"; const wqqksssaoggqceky = "\x64\151\x73\x63\162\x69\x6d\x69\x6e\141\164\x6f\x72"; const swkaqiikoaickuui = "\x6f\160\x74\151\x6d\151\172\145"; const ccoesaeoiusskiew = "\162\145\x2d\x6f\x70\x74\x69\155\x69\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\x72\147\145\x5f\x6e\x6f\156\x63\x65"; const hwawamsmicyywemy = "\143\141\x63\150\x65\137\163\x74\141\164\x75\163"; }
