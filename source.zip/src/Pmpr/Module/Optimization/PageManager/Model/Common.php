<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f13d321859c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\x63\151\141\154\x5f\x70\141\x67\x65"; const wqqksssaoggqceky = "\144\151\163\x63\x72\151\x6d\x69\x6e\x61\x74\x6f\x72"; const swkaqiikoaickuui = "\157\x70\164\151\x6d\x69\172\x65"; const ccoesaeoiusskiew = "\x72\x65\55\157\160\164\x69\155\x69\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\162\147\145\137\156\x6f\x6e\x63\145"; const hwawamsmicyywemy = "\143\141\143\150\145\x5f\163\164\x61\164\165\x73"; }
