<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f849ccf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\143\x69\141\x6c\137\x70\141\x67\x65"; const wqqksssaoggqceky = "\x64\x69\x73\x63\x72\x69\155\x69\156\141\164\157\x72"; const swkaqiikoaickuui = "\157\160\164\151\155\x69\172\145"; const ccoesaeoiusskiew = "\162\x65\x2d\x6f\160\164\x69\155\151\172\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\x72\147\x65\137\156\157\156\143\x65"; const hwawamsmicyywemy = "\x63\x61\143\150\x65\137\163\x74\141\x74\x75\x73"; }
