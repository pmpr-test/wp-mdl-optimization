<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae19a7b618             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\160\x65\x63\151\x61\154\x5f\x70\141\147\x65"; const mcewqquusaugsmmm = "\x73\x70\145\143\x69\141\154\137\x70\x61\147\x65\163"; const wqqksssaoggqceky = "\x64\151\163\143\x72\x69\155\x69\x6e\141\x74\157\x72"; const swkaqiikoaickuui = "\157\x70\x74\x69\x6d\x69\172\145"; const ccoesaeoiusskiew = "\x72\x65\55\x6f\160\x74\151\155\151\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\x72\x67\x65\137\156\x6f\x6e\x63\145"; const hwawamsmicyywemy = "\143\x61\x63\x68\x65\x5f\163\164\141\x74\x75\x73"; }
