<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f431078326f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\x63\x69\141\154\x5f\160\141\x67\145"; const wqqksssaoggqceky = "\x64\x69\x73\x63\162\151\155\x69\x6e\x61\164\x6f\x72"; const swkaqiikoaickuui = "\x6f\160\x74\151\x6d\151\x7a\145"; const ccoesaeoiusskiew = "\x72\145\x2d\x6f\x70\x74\x69\x6d\151\x7a\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\x67\145\137\156\x6f\x6e\x63\145"; const hwawamsmicyywemy = "\143\141\143\150\x65\137\163\x74\x61\164\x75\x73"; }
