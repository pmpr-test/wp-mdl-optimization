<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef50f73aec3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\163\x70\145\x63\151\x61\x6c\x5f\160\x61\147\145"; const mcewqquusaugsmmm = "\x73\160\x65\x63\x69\141\154\137\160\x61\147\x65\163"; const wqqksssaoggqceky = "\x64\x69\x73\x63\x72\151\155\151\156\x61\164\x6f\x72"; const swkaqiikoaickuui = "\157\160\x74\x69\x6d\151\172\x65"; const ccoesaeoiusskiew = "\162\145\x2d\x6f\x70\x74\x69\155\151\x7a\145"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\147\x65\137\x6e\x6f\x6e\x63\x65"; const hwawamsmicyywemy = "\143\141\x63\150\x65\x5f\x73\164\x61\x74\x75\163"; }
