<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672356236bf3e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\160\145\x63\x69\x61\x6c\x5f\x70\x61\147\x65"; const wqqksssaoggqceky = "\x64\x69\163\143\x72\151\155\x69\x6e\x61\164\x6f\162"; const swkaqiikoaickuui = "\x6f\160\x74\151\x6d\151\x7a\145"; const ccoesaeoiusskiew = "\162\145\55\157\x70\x74\x69\x6d\151\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\165\162\147\145\137\x6e\157\156\143\x65"; const hwawamsmicyywemy = "\143\141\x63\x68\x65\x5f\163\x74\x61\164\165\163"; }
