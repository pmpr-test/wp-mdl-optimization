<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc54f326c1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\x63\x69\141\154\x5f\160\x61\147\x65"; const wqqksssaoggqceky = "\144\151\x73\143\x72\151\x6d\x69\x6e\141\x74\x6f\162"; const swkaqiikoaickuui = "\x6f\160\164\x69\x6d\x69\x7a\145"; const ccoesaeoiusskiew = "\162\x65\x2d\157\x70\164\151\155\151\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\x75\162\x67\x65\x5f\156\157\156\143\x65"; const hwawamsmicyywemy = "\x63\x61\143\x68\145\137\x73\164\141\164\x75\163"; }
