<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a8053cce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Module\Optimization\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\x65\143\x69\141\154\137\x70\x61\147\x65"; const wqqksssaoggqceky = "\144\x69\163\x63\162\x69\155\x69\x6e\x61\x74\157\x72"; const swkaqiikoaickuui = "\x6f\x70\x74\151\x6d\151\x7a\145"; const ccoesaeoiusskiew = "\162\x65\x2d\x6f\x70\x74\x69\155\x69\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\x70\165\162\x67\145\137\156\157\x6e\x63\x65"; const hwawamsmicyywemy = "\x63\x61\x63\x68\x65\137\x73\164\141\x74\165\163"; }
