<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b1fa9ac4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\PageManager\Model; use Pmpr\Common\Foundation\ORM\Model; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Traits\PageManagerEngineTrait; abstract class Common extends Model { use PageManagerEngineTrait; const usoeisyyakwkuyoy = "\x73\x70\145\143\151\141\x6c\137\x70\141\x67\x65"; const wqqksssaoggqceky = "\144\151\163\x63\x72\151\155\151\x6e\141\164\x6f\162"; const swkaqiikoaickuui = "\157\160\x74\x69\x6d\x69\x7a\145"; const ccoesaeoiusskiew = "\162\x65\x2d\x6f\160\x74\151\x6d\x69\172\x65"; const qwmouieeiikqoewq = Optimization::kgswyesggeyekgmg . "\160\x75\162\x67\x65\137\156\157\156\143\x65"; const hwawamsmicyywemy = "\x63\x61\x63\150\x65\x5f\163\164\141\164\x75\163"; }
