<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d002186f7a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; use Pmpr\Module\Optimization\Traits\AlertTrait; abstract class SettingSegment extends Segment { use AlertTrait; const uogwigocosgsugqq = "\141\163\x73\x65\164\x73\x5f"; const ecykieqkcugukiae = self::uogwigocosgsugqq . "\x64\x65\x6c\141\171\x5f"; public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
