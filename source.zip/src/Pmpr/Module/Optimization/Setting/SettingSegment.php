<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76d1d04df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; use Pmpr\Module\Optimization\Traits\AlertTrait; abstract class SettingSegment extends Segment { use AlertTrait; const uogwigocosgsugqq = "\141\x73\163\145\x74\163\137"; const ecykieqkcugukiae = self::uogwigocosgsugqq . "\144\145\x6c\x61\x79\137"; public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
