<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a588a282a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; use Pmpr\Module\Optimization\Traits\AlertTrait; abstract class SettingSegment extends Segment { use AlertTrait; const uogwigocosgsugqq = "\141\x73\x73\x65\x74\163\x5f"; const ecykieqkcugukiae = self::uogwigocosgsugqq . "\144\x65\154\141\171\x5f"; public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
