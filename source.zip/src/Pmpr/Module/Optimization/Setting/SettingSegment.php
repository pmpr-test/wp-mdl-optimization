<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d7b77183e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; use Pmpr\Module\Optimization\Traits\AlertTrait; abstract class SettingSegment extends Segment { use AlertTrait; const uogwigocosgsugqq = "\141\x73\x73\x65\164\163\137"; const ecykieqkcugukiae = self::uogwigocosgsugqq . "\x64\x65\x6c\x61\x79\x5f"; public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } }
