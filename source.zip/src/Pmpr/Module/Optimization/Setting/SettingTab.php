<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f9e31abf5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; class SettingTab { }
