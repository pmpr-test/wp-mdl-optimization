<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a668241c3c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; class SettingTab { }
