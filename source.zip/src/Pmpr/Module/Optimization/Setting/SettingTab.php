<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a6679295fdc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Setting; class SettingTab { }
