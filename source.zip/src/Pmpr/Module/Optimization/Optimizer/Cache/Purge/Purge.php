<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e29caf530             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\Purge; abstract class Purge extends Common { public function yqemcmaqsuqeuugu(...$ywmkwiwkosakssii) { $this->uykissogmuaaocsg()->qsiwaqwsyasqsqcq(...$ywmkwiwkosakssii); } public abstract function uykissogmuaaocsg() : Engine; }
