<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             688b66f09a74b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\Purge; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Traits\HelperTrait; abstract class Common extends Container { use HelperTrait; }
