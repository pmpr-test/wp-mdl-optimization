<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d002186f7a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\Optimizer\Cache\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\x61\144\166\x61\156\143\145\x64\55\x34\x30\x34\x2e\160\150\x70"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(Constants::usqswcmmiaaasaki); } public function gayqqwwuycceosii() : array { return ["\x66\x69\x6c\x65\x70\x61\164\x68" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
