<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f13d321859c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\Optimizer\Cache\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\141\x64\x76\141\156\x63\x65\144\55\x34\60\x34\x2e\160\x68\160"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(Constants::usqswcmmiaaasaki); } public function gayqqwwuycceosii() : array { return ["\x66\151\154\x65\160\141\164\x68" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
