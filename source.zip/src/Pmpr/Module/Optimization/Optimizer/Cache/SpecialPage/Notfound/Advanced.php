<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f0cc89158             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\Optimizer\Cache\Advanced as BaseClass; class Advanced extends BaseClass { public function ikcgmcycisiccyuc() { $this->filename = "\141\144\166\141\156\x63\145\x64\x2d\64\x30\64\56\x70\150\160"; $this->directory = $this->caokeucsksukesyo()->iuekyyeesukysksy()->cmaecekuqkwmemms(Constants::usqswcmmiaaasaki); } public function gayqqwwuycceosii() : array { return ["\146\x69\154\145\160\x61\x74\x68" => Engine::symcgieuakksimmu()->guwogeosiyasimgk()]; } }
