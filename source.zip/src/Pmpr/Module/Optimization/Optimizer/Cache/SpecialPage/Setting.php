<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e86b3a376             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\145\143\151\141\x6c\137\160\141\147\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\145\x63\x69\141\x6c\x20\120\x61\x67\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\141\x72\143\150\54\x20\x34\x30\x34\40\x61\x6e\144\x20\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
