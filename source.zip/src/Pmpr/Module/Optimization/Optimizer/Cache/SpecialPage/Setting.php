<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f431078326f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\145\143\x69\x61\154\137\x70\141\147\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\x65\x63\x69\x61\x6c\x20\120\x61\147\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\x61\x72\143\150\x2c\x20\x34\60\64\40\141\156\144\x20\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
