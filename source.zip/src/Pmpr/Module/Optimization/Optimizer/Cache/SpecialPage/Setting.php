<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1eae701745             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\160\x65\143\151\x61\x6c\x5f\x70\x61\147\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\x70\x65\143\x69\141\154\40\120\141\147\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\141\x72\143\150\x2c\40\64\x30\64\x20\x61\x6e\x64\40\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
