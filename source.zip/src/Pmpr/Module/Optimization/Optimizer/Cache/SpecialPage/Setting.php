<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0c5f88d120             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\145\143\x69\x61\154\x5f\160\x61\x67\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\x70\145\143\x69\141\154\x20\x50\141\x67\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\x61\162\x63\x68\54\40\x34\60\x34\40\x61\156\144\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
