<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2b4f7e33a8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\160\x65\x63\x69\x61\154\x5f\160\141\147\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\x63\151\141\x6c\40\x50\141\147\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\x65\141\x72\143\x68\54\x20\64\x30\x34\40\x61\156\x64\x20\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
