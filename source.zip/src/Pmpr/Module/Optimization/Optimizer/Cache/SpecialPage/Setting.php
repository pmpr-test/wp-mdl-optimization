<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f13d321859c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\160\x65\143\151\141\x6c\x5f\x70\x61\x67\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\143\x69\x61\154\40\x50\141\147\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\x61\x72\x63\150\54\40\64\x30\64\x20\141\156\x64\x20\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
