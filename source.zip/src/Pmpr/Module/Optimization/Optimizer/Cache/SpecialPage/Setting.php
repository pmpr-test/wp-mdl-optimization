<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc54f326c1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Search\Setting as SearchSetting; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound\Setting as NotfoundSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { SearchSetting::symcgieuakksimmu(); NotfoundSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\160\145\143\x69\141\154\137\160\x61\x67\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\x63\x69\x61\154\40\120\141\x67\x65\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\x65\141\162\143\150\54\40\64\x30\64\40\x61\x6e\144\40\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
