<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd9008d45             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Search\Setting as SearchSetting; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound\Setting as NotfoundSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { SearchSetting::symcgieuakksimmu(); NotfoundSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\x70\145\x63\151\x61\154\x5f\x70\141\147\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\160\145\143\x69\x61\x6c\40\x50\x61\147\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\x65\141\x72\143\150\54\x20\64\60\x34\40\x61\x6e\x64\x20\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
