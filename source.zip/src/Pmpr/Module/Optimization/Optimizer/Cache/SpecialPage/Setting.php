<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f1c30b6e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Search\Setting as SearchSetting; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound\Setting as NotfoundSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { SearchSetting::symcgieuakksimmu(); NotfoundSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\160\x65\x63\x69\141\x6c\137\x70\141\x67\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\143\151\141\x6c\x20\120\141\147\x65\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\x65\x61\x72\143\150\54\40\x34\60\64\40\x61\x6e\x64\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
