<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb16c082ce5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\160\145\143\x69\x61\154\137\x70\x61\147\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\x63\x69\x61\154\x20\120\141\x67\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\x65\141\x72\143\x68\x2c\x20\64\60\x34\40\141\x6e\144\40\56\56\56", PR__MDL__OPTIMIZATION))); } }
