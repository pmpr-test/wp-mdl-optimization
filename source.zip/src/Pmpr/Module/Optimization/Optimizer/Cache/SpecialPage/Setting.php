<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16a50f1e99             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\x65\x63\151\x61\x6c\137\x70\x61\147\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\145\143\x69\141\x6c\x20\x50\141\147\x65\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\141\162\143\150\x2c\x20\64\60\64\x20\141\156\144\x20\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
