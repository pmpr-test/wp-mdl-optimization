<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15e8e06c9b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\145\x63\x69\141\x6c\x5f\160\x61\147\x65\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\143\x69\141\154\40\120\141\x67\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\141\x72\x63\150\x2c\40\x34\60\x34\40\x61\156\x64\40\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
