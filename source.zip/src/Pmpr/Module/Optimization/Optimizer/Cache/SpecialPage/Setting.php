<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7aea357a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\160\145\x63\151\x61\x6c\137\160\x61\147\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\145\143\151\x61\x6c\x20\x50\x61\x67\x65\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\123\145\141\162\143\150\x2c\x20\64\60\64\40\141\156\144\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
