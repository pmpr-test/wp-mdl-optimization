<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76d1d04df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\145\x63\x69\x61\x6c\137\x70\141\147\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\x53\160\145\143\151\x61\x6c\40\120\x61\147\x65\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\x61\x72\143\150\54\40\64\x30\x34\40\141\x6e\144\x20\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
