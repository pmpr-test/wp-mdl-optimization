<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eafa4785061             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\163\160\145\x63\151\141\154\137\x70\x61\x67\145\x73")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\160\x65\x63\151\141\x6c\40\x50\141\147\145\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\141\162\143\x68\x2c\x20\x34\x30\64\x20\141\x6e\x64\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
