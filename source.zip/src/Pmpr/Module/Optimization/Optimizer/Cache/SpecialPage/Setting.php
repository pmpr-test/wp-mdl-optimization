<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f849ccf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\160\x65\143\151\141\x6c\137\160\x61\147\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\x63\x69\x61\x6c\40\x50\x61\147\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\145\141\x72\143\x68\54\x20\x34\60\x34\40\x61\156\144\40\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
