<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d840ddfea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x73\x70\145\x63\151\x61\154\x5f\160\141\x67\145\163")->jyumyyugiwwiqomk(50)->saemoowcasogykak(IconInterface::ywayikesiaccomac)->gswweykyogmsyawy(__("\123\x70\x65\x63\x69\141\x6c\40\120\x61\147\145\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x53\x65\x61\162\x63\150\x2c\40\64\x30\x34\40\x61\156\x64\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
