<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f431078326f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound\Notfound; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Search\Search; class SpecialPage extends Common { public function mameiwsayuyquoeq() { Search::symcgieuakksimmu(); Setting::symcgieuakksimmu(); Notfound::symcgieuakksimmu(); } }
