<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a643167c6f8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Notfound\Notfound; use Pmpr\Module\Optimization\Optimizer\Cache\SpecialPage\Search\Search; class SpecialPage extends Container { public function mameiwsayuyquoeq() { Notfound::symcgieuakksimmu(); } }
