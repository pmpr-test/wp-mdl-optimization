<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581d1ae35f7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\HTML\Purge; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { public function ikcgmcycisiccyuc() { $this->segment = "\x68\164\x6d\154\137\143\x61\143\150\x65"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x70\165\162\147\x65")->gswweykyogmsyawy(__("\120\165\162\147\145\40\105\154\x65\143\164\x65\x64\x20\x50\x61\147\145\47\163\x20\103\141\143\150\x65", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::wuyemouocmmciyca)); } }
