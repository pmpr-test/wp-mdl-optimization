<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581ccae80ff             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\HTML\Purge; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { public function ikcgmcycisiccyuc() { $this->segment = "\150\164\x6d\154\x5f\x63\x61\143\150\145"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\160\x75\162\x67\x65")->gswweykyogmsyawy(__("\x50\165\162\147\145\x20\105\154\x65\x63\x74\145\x64\x20\x50\141\147\x65\47\163\40\103\x61\143\x68\x65", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::wuyemouocmmciyca)); } }
