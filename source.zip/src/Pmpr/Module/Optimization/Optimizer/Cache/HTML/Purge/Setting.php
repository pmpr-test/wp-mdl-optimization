<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e86b3a376             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\HTML\Purge; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { public function ikcgmcycisiccyuc() { $this->segment = "\x68\x74\x6d\x6c\x5f\x63\141\143\150\x65"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x70\x75\x72\147\x65")->gswweykyogmsyawy(__("\x50\165\162\x67\145\x20\105\154\145\x63\164\x65\x64\x20\120\x61\x67\x65\47\163\40\103\141\143\150\145", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::wuyemouocmmciyca)); } }
