<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb242fc74db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\Optimizer\Cache\Common as BaseClass; abstract class Common extends BaseClass { public function gusmkkagsgyegacm($sameaqkagyqomooq) : string { return "{$sameaqkagyqomooq}\x2e\150\x74\155\x6c"; } public function ysuiqkgycmagqqyu($sameaqkagyqomooq) : bool { return $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk()->exists($this->cckisoakyqqgywey($sameaqkagyqomooq)); } public function cckisoakyqqgywey($sameaqkagyqomooq) : string { return "{$this->gskqygiceygcguyo()}\x2f{$this->gusmkkagsgyegacm($sameaqkagyqomooq)}"; } public function gskqygiceygcguyo() : ?string { return $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(VirtualBrowser::cmiuooquqeyoccay, ''); } }
