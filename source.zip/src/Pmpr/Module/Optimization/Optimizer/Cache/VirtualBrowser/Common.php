<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4dfc43710             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\Optimizer\Cache\Common as BaseClass; abstract class Common extends BaseClass { public function gusmkkagsgyegacm($sameaqkagyqomooq) : string { return "{$sameaqkagyqomooq}\56\150\164\155\154"; } public function ysuiqkgycmagqqyu($sameaqkagyqomooq) : bool { return $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk()->exists($this->cckisoakyqqgywey($sameaqkagyqomooq)); } public function cckisoakyqqgywey($sameaqkagyqomooq) : string { return "{$this->gskqygiceygcguyo()}\x2f{$this->gusmkkagsgyegacm($sameaqkagyqomooq)}"; } public function gskqygiceygcguyo() : ?string { return $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(VirtualBrowser::cmiuooquqeyoccay, ''); } }
