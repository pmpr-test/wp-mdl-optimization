<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f1c30b6e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Module\Optimization\Container; abstract class Common extends Container { public function gusmkkagsgyegacm($sameaqkagyqomooq) : string { return "{$sameaqkagyqomooq}\56\x68\164\155\154"; } public function ysuiqkgycmagqqyu($sameaqkagyqomooq) : bool { return $this->caokeucsksukesyo()->iuekyyeesukysksy()->kcciqwskewsuaemk()->exists($this->cckisoakyqqgywey($sameaqkagyqomooq)); } public function cckisoakyqqgywey($sameaqkagyqomooq) : string { return "{$this->gskqygiceygcguyo()}\57{$this->gusmkkagsgyegacm($sameaqkagyqomooq)}"; } public function gskqygiceygcguyo() : ?string { return $this->caokeucsksukesyo()->eiwcuqigayigimak()->cmaecekuqkwmemms(VirtualBrowser::cmiuooquqeyoccay, ''); } }
