<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf66918980             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Remote; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\157\160\x74\x69\155\151\x7a\141\164\x69\x6f\156"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $ccowyogiqwikkkie, $umkiakawyaakcsqm) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f{$this->gueasuouwqysmomu()}\x2f\x61\x64\144\x2d\152\157\142", [self::kugiewcgiawaeiaq => [Constants::auqoykcmsiauccao => $eeamcawaiqocomwy, Constants::aciemiuuwgysykom => $this->eegcqkwceasicmek(), Constants::myikkigscysoykgy => $ccowyogiqwikkkie, "\x72\x65\x73\x6f\x6c\x75\164\x69\x6f\x6e\x73" => $umkiakawyaakcsqm]], Constants::mswoacegomcucaik); if (is_wp_error($sogksuscggsicmac)) { goto skaayekywasksoug; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue, []); skaayekywasksoug: return $sogksuscggsicmac; } }
