<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc08864f41             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Remote; use WP_Error; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\x6f\160\x74\x69\155\151\x7a\141\x74\x69\x6f\156"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $umkiakawyaakcsqm) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57{$this->gueasuouwqysmomu()}\57\x61\x64\x64\x2d\152\157\142", [self::kugiewcgiawaeiaq => ["\x72\x65\163\x6f\x6c\x75\x74\x69\157\x6e\x73" => $umkiakawyaakcsqm, Constants::auqoykcmsiauccao => $eeamcawaiqocomwy, Constants::aciemiuuwgysykom => $this->caokeucsksukesyo()->cqusmgskowmesgcg()->ooouaomcuuakuaii()]], Constants::mswoacegomcucaik); if (!is_wp_error($sogksuscggsicmac)) { $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue, []); } return $sogksuscggsicmac; } }
