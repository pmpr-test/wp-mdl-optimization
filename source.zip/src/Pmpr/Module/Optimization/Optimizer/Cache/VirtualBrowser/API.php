<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eaf9d55aac3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Remote; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\157\x70\164\x69\155\151\172\141\x74\x69\157\x6e"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $ccowyogiqwikkkie, $umkiakawyaakcsqm) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f{$this->gueasuouwqysmomu()}\57\141\x64\x64\x2d\x6a\x6f\142", [self::kugiewcgiawaeiaq => [Constants::auqoykcmsiauccao => $eeamcawaiqocomwy, Constants::aciemiuuwgysykom => $this->eegcqkwceasicmek(), Constants::myikkigscysoykgy => $ccowyogiqwikkkie, "\162\145\x73\x6f\x6c\165\164\x69\x6f\156\x73" => $umkiakawyaakcsqm]], Constants::mswoacegomcucaik); if (is_wp_error($sogksuscggsicmac)) { goto uykwmucgoywoesui; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue, []); uykwmucgoywoesui: return $sogksuscggsicmac; } }
