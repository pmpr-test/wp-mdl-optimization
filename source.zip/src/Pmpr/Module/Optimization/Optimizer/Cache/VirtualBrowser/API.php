<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76d1d04df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Remote; use WP_Error; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\157\160\164\151\155\151\x7a\141\164\x69\157\x6e"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $umkiakawyaakcsqm) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f{$this->gueasuouwqysmomu()}\x2f\x61\144\x64\x2d\x6a\x6f\142", [self::kugiewcgiawaeiaq => ["\162\x65\x73\157\x6c\x75\x74\x69\157\x6e\163" => $umkiakawyaakcsqm, Constants::auqoykcmsiauccao => $eeamcawaiqocomwy, Constants::aciemiuuwgysykom => $this->eegcqkwceasicmek()]], Constants::mswoacegomcucaik); if (is_wp_error($sogksuscggsicmac)) { goto swckikycciugciqq; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue, []); swckikycciugciqq: return $sogksuscggsicmac; } }
