<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb25af783f1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Remote; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\157\x70\x74\151\x6d\x69\172\x61\164\x69\x6f\156"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $ccowyogiqwikkkie, $umkiakawyaakcsqm) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57{$this->gueasuouwqysmomu()}\57\x61\x64\x64\55\152\x6f\x62", [self::kugiewcgiawaeiaq => [Constants::auqoykcmsiauccao => $eeamcawaiqocomwy, Constants::aciemiuuwgysykom => $this->eegcqkwceasicmek(), Constants::myikkigscysoykgy => $ccowyogiqwikkkie, "\x72\x65\x73\x6f\154\165\x74\x69\x6f\x6e\x73" => $umkiakawyaakcsqm]], Constants::mswoacegomcucaik); if (is_wp_error($sogksuscggsicmac)) { goto uykwmucgoywoesui; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue, []); uykwmucgoywoesui: return $sogksuscggsicmac; } }
