<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4c436ce06             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Remote; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\157\x70\164\151\155\x69\172\x61\x74\151\x6f\156"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $ccowyogiqwikkkie, $umkiakawyaakcsqm) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f{$this->gueasuouwqysmomu()}\x2f\141\x64\x64\x2d\x6a\x6f\x62", [self::kugiewcgiawaeiaq => ["\x72\145\x73\157\x6c\165\164\151\157\x6e\163" => $umkiakawyaakcsqm, Constants::auqoykcmsiauccao => $eeamcawaiqocomwy, Constants::aciemiuuwgysykom => $this->eegcqkwceasicmek(), Constants::myikkigscysoykgy => $ccowyogiqwikkkie]], Constants::mswoacegomcucaik); if (is_wp_error($sogksuscggsicmac)) { goto aayysiegiyweiyuu; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue, []); aayysiegiyweiyuu: return $sogksuscggsicmac; } }
