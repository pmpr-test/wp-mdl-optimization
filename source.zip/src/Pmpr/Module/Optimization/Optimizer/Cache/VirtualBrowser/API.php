<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758102f55148             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Remote; use WP_Error; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\157\x70\x74\x69\x6d\x69\x7a\141\164\151\157\x6e"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $umkiakawyaakcsqm) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f{$this->gueasuouwqysmomu()}\57\141\x64\144\55\x6a\x6f\142", [self::kugiewcgiawaeiaq => ["\x72\145\x73\157\154\165\x74\x69\x6f\156\x73" => $umkiakawyaakcsqm, Constants::auqoykcmsiauccao => $eeamcawaiqocomwy, Constants::aciemiuuwgysykom => $this->caokeucsksukesyo()->cqusmgskowmesgcg()->ooouaomcuuakuaii()]], Constants::mswoacegomcucaik); if (!is_wp_error($sogksuscggsicmac)) { $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue, []); } return $sogksuscggsicmac; } }
