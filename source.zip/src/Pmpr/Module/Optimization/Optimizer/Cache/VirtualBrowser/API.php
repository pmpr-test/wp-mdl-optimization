<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f849ccf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Cache\VirtualBrowser; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Remote; use WP_Error; class API extends Remote { public function ikcgmcycisiccyuc() { $this->type = "\x6f\x70\164\151\155\x69\x7a\x61\x74\x69\x6f\156"; } public function wysoaqkkayeussmu($eeamcawaiqocomwy, $umkiakawyaakcsqm) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f{$this->gueasuouwqysmomu()}\57\141\x64\x64\55\152\x6f\142", [self::kugiewcgiawaeiaq => ["\162\145\x73\157\154\x75\164\x69\157\156\163" => $umkiakawyaakcsqm, Constants::auqoykcmsiauccao => $eeamcawaiqocomwy, Constants::aciemiuuwgysykom => $this->eegcqkwceasicmek()]], Constants::mswoacegomcucaik); if (is_wp_error($sogksuscggsicmac)) { goto coogyackikgmecic; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue, []); coogyackikgmecic: return $sogksuscggsicmac; } }
