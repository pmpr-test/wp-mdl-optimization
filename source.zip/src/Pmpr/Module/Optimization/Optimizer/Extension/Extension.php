<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2b472f16c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimizer\Extension\Cover\Cover; use Pmpr\Module\Optimization\Optimizer\Extension\Module\Module; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Plugin; use Pmpr\Module\Optimization\Optimizer\Extension\Theme\Theme; class Extension extends Common { public function mameiwsayuyquoeq() { Plugin::symcgieuakksimmu(); if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto yseacqgykcseamce; } Setting::symcgieuakksimmu(); Component::symcgieuakksimmu(); yseacqgykcseamce: } }
