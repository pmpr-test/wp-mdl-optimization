<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68855802117a9             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimizer\Extension\Cover\Cover; use Pmpr\Module\Optimization\Optimizer\Extension\Module\Module; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Plugin; use Pmpr\Module\Optimization\Optimizer\Extension\Theme\Theme; class Extension extends Container { public function mameiwsayuyquoeq() { Plugin::symcgieuakksimmu(); if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { Component::symcgieuakksimmu(); } } }
