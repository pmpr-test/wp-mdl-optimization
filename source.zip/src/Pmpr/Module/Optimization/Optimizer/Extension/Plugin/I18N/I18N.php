<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             688b2e42c4cf1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\I18N; use Pmpr\Module\Optimization\Container; class I18N extends Container { }
