<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6886683f26f14             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\CDN; use Pmpr\Module\Optimization\Container; class CDN extends Container { public function mameiwsayuyquoeq() { } }
