<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e04ea1945             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Slider; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Slider\SliderRevolution\SliderRevolution; class Slider extends Common { public function mameiwsayuyquoeq() { $cekyiayaygawemyq = $this->caokeucsksukesyo()->essaugkeosgskqme(); if (!$cekyiayaygawemyq->ggocakcisguuokai("\162\145\x76\x73\x6c\x69\x64\145\162\x2f\x72\145\x76\163\154\x69\144\145\162\x2e\x70\x68\x70")) { goto aagewueuesckuqke; } SliderRevolution::symcgieuakksimmu(); aagewueuesckuqke: } }
