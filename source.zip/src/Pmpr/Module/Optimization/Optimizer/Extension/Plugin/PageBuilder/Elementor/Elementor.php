<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a8053cce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\PageBuilder\Elementor; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Common; class Elementor extends Common { public function mameiwsayuyquoeq() { Engine::symcgieuakksimmu(); } }
