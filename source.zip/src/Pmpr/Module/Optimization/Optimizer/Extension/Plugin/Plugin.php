<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6889feab0a8bc             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\PageBuilder\Elementor\Elementor; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Slider\SliderRevolution\SliderRevolution; class Plugin extends Container { public function mameiwsayuyquoeq() { $cekyiayaygawemyq = $this->caokeucsksukesyo()->essaugkeosgskqme(); if ($cekyiayaygawemyq->ggocakcisguuokai('revslider/revslider.php')) { SliderRevolution::symcgieuakksimmu(); } if ($cekyiayaygawemyq->kyiokwokcqqmgicy()) { Elementor::symcgieuakksimmu(); } } }
