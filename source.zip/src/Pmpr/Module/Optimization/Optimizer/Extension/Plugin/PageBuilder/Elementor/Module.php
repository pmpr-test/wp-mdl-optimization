<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76d1d04df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\PageBuilder\Elementor; use Elementor\Core\Base\Document; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Common; abstract class Module extends Common { public function aicaiommyggoqoks(array $siquossayskcwkea, Document $cmckowaakauyescq) : array { return $siquossayskcwkea; } public function eweuqkioyiiiqgcw(Document $cmckowaakauyescq) : string { return ''; } public function aimycmkwossgasgs(string $ewgwqamkygiqaawc, Document $cmckowaakauyescq) : string { return $ewgwqamkygiqaawc; } public function ieoqyoeecukogies(Document $cmckowaakauyescq) : string { return ''; } }
