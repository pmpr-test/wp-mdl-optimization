<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc54f326c1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\PageBuilder\Elementor\Setting as ElementorSetting; use Pmpr\Module\Optimization\Setting\TabSetting; class Setting extends TabSetting { public function ikcgmcycisiccyuc() { $this->segment = "\145\170\x74\145\156\x73\151\x6f\x6e"; parent::ikcgmcycisiccyuc(); } public function mameiwsayuyquoeq() { ElementorSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->aucimgwswmgaocae($this->doeuiogekyiwgsgw("\x70\x6c\165\x67\x69\156")->gswweykyogmsyawy(__("\120\154\x75\x67\151\x6e\x73", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::csoyqymugwqiggki)); } }
