<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d8d7adaa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\PageBuilder\Elementor\Setting as ElementorSetting; use Pmpr\Module\Optimization\Setting\TabSetting; class Setting extends TabSetting { public function ikcgmcycisiccyuc() { $this->segment = "\x65\170\x74\x65\156\163\151\157\x6e"; parent::ikcgmcycisiccyuc(); } public function mameiwsayuyquoeq() { ElementorSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->aucimgwswmgaocae($this->doeuiogekyiwgsgw("\x70\154\165\x67\151\156")->gswweykyogmsyawy(__("\120\x6c\165\x67\x69\156\x73", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::csoyqymugwqiggki)); } }
