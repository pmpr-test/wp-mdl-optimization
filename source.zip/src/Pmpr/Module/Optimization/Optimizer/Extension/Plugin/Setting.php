<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581596084c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\PageBuilder\Elementor\Setting as ElementorSetting; use Pmpr\Module\Optimization\Setting\TabSetting; class Setting extends TabSetting { public function ikcgmcycisiccyuc() { $this->segment = "\145\x78\x74\x65\x6e\x73\x69\157\156"; parent::ikcgmcycisiccyuc(); } public function mameiwsayuyquoeq() { ElementorSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->aucimgwswmgaocae($this->doeuiogekyiwgsgw("\x70\x6c\165\x67\151\x6e")->gswweykyogmsyawy(__("\x50\154\165\x67\151\156\x73", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::csoyqymugwqiggki)); } }
