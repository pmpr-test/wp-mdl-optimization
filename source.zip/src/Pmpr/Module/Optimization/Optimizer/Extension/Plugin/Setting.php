<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f849ccf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\TabSetting; class Setting extends TabSetting { public function ikcgmcycisiccyuc() { $this->segment = "\x65\x78\164\x65\x6e\x73\151\157\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->aucimgwswmgaocae($this->doeuiogekyiwgsgw("\160\x6c\x75\147\151\x6e")->gswweykyogmsyawy(__("\x50\x6c\x75\x67\151\x6e\163", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::csoyqymugwqiggki)); } }
