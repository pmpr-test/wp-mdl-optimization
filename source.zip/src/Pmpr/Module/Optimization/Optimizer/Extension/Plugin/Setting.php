<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e86b3a376             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\TabSetting; class Setting extends TabSetting { public function ikcgmcycisiccyuc() { $this->segment = "\145\170\x74\145\x6e\163\x69\157\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->aucimgwswmgaocae($this->doeuiogekyiwgsgw("\160\154\165\147\x69\x6e")->gswweykyogmsyawy(__("\x50\x6c\165\x67\x69\156\163", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::csoyqymugwqiggki)); } }
