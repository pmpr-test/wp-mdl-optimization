<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757fc94b167d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Ecommerce; use Pmpr\Module\Optimization\Container; class Woocommerce extends Container { }
