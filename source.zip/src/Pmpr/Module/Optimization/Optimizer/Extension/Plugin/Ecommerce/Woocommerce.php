<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1ea51a7c51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Ecommerce; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Common; class Woocommerce extends Common { }
