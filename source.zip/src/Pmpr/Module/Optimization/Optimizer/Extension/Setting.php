<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4c436ce06             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\145\x6e\x73\151\x6f\156")->gswweykyogmsyawy(__("\x45\170\x74\x65\156\163\151\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\165\x6c\x65\x73\x2c\x20\143\157\x76\145\x72\x73\x2c\x20\x70\x6c\x75\x67\x69\x6e\x73\x20\x61\156\144\x20\x74\150\x65\x6d\145\163\x20\x43\x6f\156\x66\151\147\x75\162\x61\164\151\x6f\x6e"))); } }
