<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15eb116f20             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\145\156\163\151\x6f\156")->gswweykyogmsyawy(__("\x45\x78\x74\x65\156\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\x64\x75\x6c\145\163\x2c\40\x63\x6f\x76\x65\x72\163\x2c\40\x70\x6c\x75\147\x69\x6e\163\40\141\156\x64\x20\x74\150\x65\155\x65\163\40\103\x6f\156\146\151\147\x75\x72\x61\164\151\157\x6e"))); } }
