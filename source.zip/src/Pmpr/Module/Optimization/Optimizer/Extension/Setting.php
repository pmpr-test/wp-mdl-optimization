<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e823d067d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\x65\156\163\151\x6f\x6e")->gswweykyogmsyawy(__("\x45\x78\x74\x65\x6e\x73\151\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\x64\165\x6c\145\163\x2c\x20\143\157\166\x65\x72\163\54\x20\x70\154\x75\147\x69\156\x73\x20\x61\156\x64\40\164\150\x65\x6d\x65\x73\x20\x43\157\156\x66\151\x67\165\162\x61\164\151\157\156"))); } }
