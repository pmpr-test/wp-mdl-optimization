<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0c5f88d120             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\x65\156\163\151\x6f\x6e")->gswweykyogmsyawy(__("\105\170\x74\145\156\x73\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\165\154\145\163\x2c\40\143\157\x76\x65\162\163\x2c\40\x70\x6c\165\147\x69\156\x73\40\141\156\x64\x20\164\x68\145\155\x65\x73\40\x43\157\x6e\x66\151\147\x75\x72\x61\164\x69\157\156"))); } }
