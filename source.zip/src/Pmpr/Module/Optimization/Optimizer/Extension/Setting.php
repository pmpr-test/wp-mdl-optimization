<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c4541eb2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Setting as PluginSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { PluginSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\x65\x6e\x73\x69\157\x6e")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\x78\x74\145\x6e\x73\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\x75\154\x65\x73\x2c\x20\x63\157\x76\145\162\x73\x2c\40\x70\x6c\x75\147\151\156\163\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
