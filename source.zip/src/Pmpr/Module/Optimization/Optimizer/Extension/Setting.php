<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eafa4785061             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\x65\156\163\x69\157\x6e")->gswweykyogmsyawy(__("\105\170\x74\145\156\x73\151\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\165\154\x65\163\54\40\x63\x6f\166\x65\162\163\x2c\40\x70\x6c\x75\x67\151\x6e\x73\x20\141\x6e\x64\x20\164\x68\x65\155\145\163\40\x43\157\156\146\x69\147\165\162\x61\x74\x69\157\x6e"))); } }
