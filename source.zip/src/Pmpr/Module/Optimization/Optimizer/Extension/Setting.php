<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581596084c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Setting as PluginSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { PluginSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\164\145\156\x73\x69\157\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\x45\x78\164\145\156\x73\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\144\165\x6c\x65\163\x2c\40\x63\x6f\x76\145\x72\x73\x2c\40\160\x6c\x75\147\x69\156\x73\56\56\56", PR__MDL__OPTIMIZATION))); } }
