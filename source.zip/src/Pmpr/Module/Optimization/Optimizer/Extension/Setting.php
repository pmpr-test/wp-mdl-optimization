<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a588a282a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\x65\x6e\x73\x69\157\x6e")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\x78\164\x65\x6e\x73\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\165\x6c\x65\x73\54\40\143\157\x76\145\x72\x73\x2c\40\x70\154\x75\x67\x69\156\x73\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
