<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f849ccf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\x65\x6e\x73\151\157\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\x45\x78\x74\x65\156\x73\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\165\154\x65\x73\x2c\x20\143\157\166\x65\x72\x73\x2c\x20\x70\x6c\x75\x67\151\156\x73\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
