<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d7b77183e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\145\x6e\x73\151\157\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\x45\x78\x74\145\x6e\163\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\x75\154\x65\x73\x2c\x20\143\157\x76\x65\x72\x73\x2c\x20\160\x6c\x75\147\x69\x6e\x73\56\56\56", PR__MDL__OPTIMIZATION))); } }
