<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a60d5dfe2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\x65\156\163\151\x6f\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\170\164\x65\x6e\x73\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\144\x75\154\x65\163\x2c\x20\x63\157\x76\x65\x72\163\x2c\x20\x70\154\x75\x67\151\x6e\163\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
