<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec78c96fd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\x65\x6e\163\151\157\x6e")->gswweykyogmsyawy(__("\x45\x78\164\145\x6e\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\x75\x6c\x65\163\x2c\x20\143\x6f\166\x65\x72\163\x2c\40\x70\154\x75\147\151\156\x73\40\x61\156\x64\x20\x74\x68\145\x6d\x65\163\40\103\x6f\156\146\x69\x67\x75\x72\x61\164\x69\x6f\156"))); } }
