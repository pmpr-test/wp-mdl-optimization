<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e29caf530             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\x65\156\x73\x69\157\x6e")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\x45\x78\164\145\156\163\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\165\154\x65\163\x2c\x20\x63\157\166\145\162\x73\x2c\40\160\x6c\165\147\151\156\x73\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
