<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b5b18721             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\145\156\163\x69\157\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\170\x74\145\156\x73\x69\x6f\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\144\x75\x6c\145\163\54\x20\x63\157\x76\145\162\x73\x2c\40\160\154\165\x67\x69\x6e\163\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
