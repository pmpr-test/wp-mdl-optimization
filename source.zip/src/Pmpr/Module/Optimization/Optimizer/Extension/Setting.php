<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb16c082ce5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\145\x6e\x73\x69\x6f\156")->gswweykyogmsyawy(__("\x45\170\164\x65\156\163\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\x75\154\145\x73\x2c\40\x63\x6f\166\145\x72\x73\54\x20\x70\154\165\x67\151\156\x73\40\x61\x6e\144\x20\164\x68\x65\155\145\163\x20\103\157\156\146\x69\x67\165\x72\141\x74\151\157\x6e"))); } }
