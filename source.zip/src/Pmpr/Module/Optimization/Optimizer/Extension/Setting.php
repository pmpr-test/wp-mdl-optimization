<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77c48a139             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\170\x74\x65\156\163\151\x6f\x6e")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\170\164\x65\x6e\163\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\144\x75\x6c\x65\x73\54\x20\143\157\x76\x65\x72\163\x2c\40\160\154\165\147\x69\x6e\163\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
