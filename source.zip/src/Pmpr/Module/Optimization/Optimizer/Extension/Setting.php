<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16a50f1e99             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\x74\145\156\x73\151\x6f\x6e")->gswweykyogmsyawy(__("\105\x78\x74\x65\x6e\x73\x69\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\144\165\x6c\x65\163\x2c\x20\143\157\166\x65\x72\163\54\x20\x70\154\165\x67\151\x6e\163\x20\141\156\x64\40\x74\150\x65\x6d\x65\163\x20\103\157\x6e\x66\151\147\165\162\x61\x74\x69\157\x6e"))); } }
