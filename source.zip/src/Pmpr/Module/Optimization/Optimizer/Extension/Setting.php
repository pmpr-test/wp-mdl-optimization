<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1377d8db9a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\x74\x65\156\x73\x69\157\x6e")->gswweykyogmsyawy(__("\105\170\164\145\156\163\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\157\x64\x75\x6c\145\163\54\x20\x63\x6f\x76\x65\x72\x73\x2c\x20\x70\x6c\165\147\151\x6e\163\40\141\156\x64\40\x74\150\145\155\145\x73\x20\x43\157\x6e\x66\x69\147\165\x72\141\x74\x69\157\x6e"))); } }
