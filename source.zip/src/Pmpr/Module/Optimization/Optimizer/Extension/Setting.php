<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e86b3a376             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\x74\145\156\163\151\157\x6e")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\170\164\145\156\163\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\x75\x6c\x65\x73\x2c\40\x63\157\166\x65\x72\163\54\x20\160\x6c\165\x67\151\156\163\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
