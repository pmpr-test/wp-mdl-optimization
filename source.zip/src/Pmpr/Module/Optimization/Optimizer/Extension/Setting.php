<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb25ce6cfc8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\x65\x6e\163\x69\157\156")->gswweykyogmsyawy(__("\x45\170\x74\x65\x6e\163\151\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\165\154\145\x73\54\x20\x63\157\x76\x65\162\x73\x2c\x20\x70\154\x75\147\151\x6e\163\40\141\x6e\144\x20\x74\x68\x65\x6d\x65\x73\x20\x43\157\156\x66\151\147\165\162\141\164\151\x6f\x6e"))); } }
