<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d840ddfea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\170\164\145\x6e\x73\x69\157\x6e")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\x78\164\x65\156\x73\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\165\x6c\145\163\54\40\x63\x6f\x76\145\162\x73\54\x20\x70\x6c\165\147\x69\x6e\x73\56\56\56", PR__MDL__OPTIMIZATION))); } }
