<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f18cb37259d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\164\x65\x6e\x73\151\x6f\x6e")->gswweykyogmsyawy(__("\x45\x78\x74\x65\x6e\x73\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\165\x6c\145\x73\54\40\143\x6f\x76\x65\x72\163\54\40\x70\154\x75\x67\151\x6e\x73\x20\141\156\x64\40\x74\x68\x65\x6d\x65\x73\x20\103\157\x6e\146\151\x67\x75\162\x61\164\151\x6f\x6e"))); } }
