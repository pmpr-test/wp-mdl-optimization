<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6723572e2b020             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\Extension\Plugin\Setting as PluginSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { PluginSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\145\156\x73\x69\x6f\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\x78\x74\x65\x6e\x73\x69\157\156", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\x4d\x6f\x64\165\154\145\163\x2c\x20\143\x6f\166\x65\x72\163\x2c\40\x70\x6c\165\147\x69\156\163\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
