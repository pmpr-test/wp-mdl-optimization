<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27a0f7c0c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\145\156\x73\x69\x6f\x6e")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\105\x78\x74\x65\x6e\163\151\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\x6f\x64\165\154\145\x73\54\40\143\x6f\x76\145\162\163\x2c\x20\160\154\165\147\x69\156\x73\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
