<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae19a7b618             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x65\x78\164\145\156\163\x69\157\x6e")->gswweykyogmsyawy(__("\105\170\164\x65\x6e\x73\x69\157\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\165\154\145\x73\x2c\40\x63\x6f\x76\145\x72\163\54\40\160\154\165\147\151\156\163\40\x61\156\144\40\x74\x68\145\155\145\x73\x20\x43\157\x6e\146\x69\x67\165\162\x61\164\x69\x6f\156"))); } }
