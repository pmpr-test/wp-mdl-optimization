<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1ea51a7c51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\145\x78\x74\x65\156\x73\x69\x6f\156")->jyumyyugiwwiqomk(5)->gswweykyogmsyawy(__("\x45\x78\164\145\x6e\x73\151\x6f\x6e", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::ouqyiwcmkcoymkqk)->gucwmccyimoagwcm(__("\115\157\x64\165\154\x65\163\54\x20\143\157\166\145\162\x73\54\40\x70\154\165\x67\151\156\163\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
