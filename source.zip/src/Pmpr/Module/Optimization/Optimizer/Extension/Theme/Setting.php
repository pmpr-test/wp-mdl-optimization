<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c4541eb2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Theme; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\TabSetting; class Setting extends TabSetting { public function ikcgmcycisiccyuc() { $this->segment = "\145\170\164\145\x6e\x73\x69\157\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->aucimgwswmgaocae($this->doeuiogekyiwgsgw("\164\x68\145\155\145")->gswweykyogmsyawy(__("\x54\150\x65\155\x65", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::aakkqqcouuoqymkg)); } }
