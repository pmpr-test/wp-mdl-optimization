<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d840ddfea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Theme; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\TabSetting; class Setting extends TabSetting { public function ikcgmcycisiccyuc() { $this->segment = "\145\x78\164\x65\156\x73\151\157\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->aucimgwswmgaocae($this->doeuiogekyiwgsgw("\164\x68\145\x6d\x65")->gswweykyogmsyawy(__("\x54\150\x65\155\145", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::aakkqqcouuoqymkg)); } }
