<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705177f65977             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Theme; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\TabSetting; class Setting extends TabSetting { public function ikcgmcycisiccyuc() { $this->segment = "\145\170\164\x65\x6e\x73\x69\157\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->aucimgwswmgaocae($this->doeuiogekyiwgsgw("\x74\150\145\x6d\x65")->gswweykyogmsyawy(__("\124\150\145\155\145", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::aakkqqcouuoqymkg)); } }
