<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b73d10da1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Theme; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\TabSetting; class Setting extends TabSetting { public function ikcgmcycisiccyuc() { $this->segment = "\x65\x78\x74\145\156\163\151\x6f\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->aucimgwswmgaocae($this->doeuiogekyiwgsgw("\x74\150\145\155\x65")->gswweykyogmsyawy(__("\x54\150\145\x6d\x65", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::aakkqqcouuoqymkg)); } }
