<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             688b26f9c16d8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Theme; use Pmpr\Module\Optimization\Container; class Theme extends Container { }
