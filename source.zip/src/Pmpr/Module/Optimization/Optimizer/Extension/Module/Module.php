<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0c9956f5c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension\Module; use Pmpr\Module\Optimization\Optimizer\Extension\Common; class Module extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); } }
