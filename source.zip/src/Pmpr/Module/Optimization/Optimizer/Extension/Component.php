<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b1fa9ac4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\x70\162\x5f\x63\157\x6d\160\157\x6e\x65\x6e\164\137\143\x68\x61\156\x67\145\144", [$this, "\155\x65\x6b\153\167\x6d\141\x63\163\x79\157\165\x71\171\x75\x6d"]); $this->waqewsckuayqguos("\x73\x65\164\164\151\x6e\147\x5f\x6f\160\x74\x69\x6f\156\163\137\x73\141\x76\145\144", [$this, "\155\145\x6b\x6b\167\155\x61\x63\x73\171\x6f\165\161\x79\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\x75\162\147\x65\x5f\x68\164\155\154\137\x63\x61\x63\x68\x65"); } }
