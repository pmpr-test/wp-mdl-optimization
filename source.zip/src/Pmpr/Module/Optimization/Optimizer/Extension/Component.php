<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7aea357a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\x72\137\143\157\x6d\160\157\x6e\145\156\x74\137\143\x68\x61\x6e\x67\x65\144", [$this, "\155\145\x6b\153\167\x6d\141\x63\x73\171\157\165\x71\171\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\164\164\151\x6e\x67\137\x6f\160\x74\151\x6f\x6e\x73\x5f\163\x61\x76\x65\x64", [$this, "\x6d\145\153\153\167\155\141\x63\x73\171\157\165\x71\171\165\155"]); } public function mekkwmacsyouqyum() { } }
