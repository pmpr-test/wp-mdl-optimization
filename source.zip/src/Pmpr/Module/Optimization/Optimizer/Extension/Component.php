<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eaf9d55aac3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\x70\x72\137\143\157\x6d\x70\157\x6e\145\x6e\x74\137\x63\x68\141\156\x67\x65\144", [$this, "\x6d\145\153\153\167\x6d\141\143\163\x79\157\x75\x71\171\165\155"]); $this->waqewsckuayqguos("\163\145\164\x74\151\x6e\x67\137\x6f\160\164\151\x6f\156\163\137\163\x61\166\x65\144", [$this, "\x6d\145\153\153\167\x6d\141\143\163\171\157\x75\161\x79\x75\x6d"]); } public function mekkwmacsyouqyum() { } }
