<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4dfc43710             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\162\137\x63\157\x6d\x70\x6f\x6e\145\156\164\137\143\x68\141\156\x67\x65\x64", [$this, "\x6d\145\x6b\153\x77\155\141\143\x73\x79\157\x75\x71\171\165\155"]); $this->waqewsckuayqguos("\163\145\164\164\151\156\x67\137\x6f\160\x74\x69\x6f\156\163\137\163\141\x76\x65\144", [$this, "\x6d\145\153\153\167\x6d\141\143\x73\171\157\x75\x71\x79\165\155"]); } public function mekkwmacsyouqyum() { } }
