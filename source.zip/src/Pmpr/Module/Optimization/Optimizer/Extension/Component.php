<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a588a282a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\162\x5f\143\x6f\155\160\157\156\x65\156\x74\x5f\143\150\x61\x6e\147\145\144", [$this, "\155\145\153\x6b\x77\x6d\141\x63\x73\171\157\x75\161\171\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\164\151\x6e\147\137\x6f\x70\x74\151\x6f\x6e\163\x5f\163\141\166\145\144", [$this, "\x6d\x65\153\x6b\167\155\141\143\163\x79\157\x75\161\x79\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\x75\x72\x67\145\x5f\143\141\143\x68\145"); } }
