<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd9008d45             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\162\x5f\x63\x6f\x6d\x70\157\156\145\x6e\x74\x5f\x63\x68\x61\x6e\147\x65\144", [$this, "\155\x65\153\x6b\x77\x6d\x61\143\163\171\x6f\x75\x71\171\165\x6d"]); $this->waqewsckuayqguos("\163\x65\164\x74\x69\x6e\x67\x5f\x6f\x70\x74\x69\157\x6e\x73\137\163\x61\x76\145\144", [$this, "\x6d\x65\153\x6b\167\155\x61\x63\x73\171\x6f\x75\161\x79\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\165\x72\x67\x65\137\x68\x74\x6d\154\x5f\143\x61\143\x68\x65"); } }
