<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758114e5f226             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\x70\162\137\143\157\155\x70\x6f\156\145\x6e\164\x5f\x63\x68\x61\156\x67\145\144", [$this, "\155\x65\x6b\x6b\x77\155\x61\x63\163\x79\x6f\165\161\x79\x75\155"]); $this->waqewsckuayqguos("\163\145\164\x74\x69\156\x67\137\x6f\x70\x74\x69\x6f\x6e\163\137\163\x61\166\145\x64", [$this, "\x6d\145\153\x6b\x77\155\x61\143\x73\171\x6f\165\x71\171\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\165\x72\147\145\137\x68\x74\x6d\154\137\143\141\x63\x68\x65"); } }
