<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08ff06dc0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\x70\162\x5f\x63\x6f\x6d\160\157\x6e\x65\156\164\x5f\143\150\141\x6e\x67\x65\x64", [$this, "\x6d\145\x6b\x6b\x77\155\141\143\x73\x79\157\165\x71\x79\x75\155"]); $this->waqewsckuayqguos("\163\145\164\x74\151\156\x67\x5f\x6f\x70\164\151\157\156\163\137\163\141\x76\145\x64", [$this, "\155\x65\153\153\x77\x6d\x61\143\x73\x79\x6f\x75\x71\x79\165\155"]); } public function mekkwmacsyouqyum() { } }
