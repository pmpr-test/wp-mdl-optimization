<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20b994df3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\x72\137\x63\157\155\160\157\156\x65\x6e\164\x5f\143\x68\x61\x6e\x67\145\x64", [$this, "\x6d\145\x6b\153\x77\155\141\143\163\x79\x6f\x75\x71\171\x75\155"]); $this->waqewsckuayqguos("\163\145\x74\164\x69\156\x67\137\x6f\160\x74\x69\x6f\156\163\137\x73\141\x76\145\144", [$this, "\x6d\145\153\x6b\167\155\141\143\163\x79\x6f\x75\x71\171\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\165\x72\x67\145\x5f\x68\x74\x6d\x6c\137\143\141\143\150\x65"); } }
