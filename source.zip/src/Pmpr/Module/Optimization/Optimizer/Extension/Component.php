<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a1764bb6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\x72\137\x63\x6f\x6d\160\x6f\x6e\145\156\x74\137\x63\x68\141\x6e\147\x65\144", [$this, "\x6d\x65\x6b\x6b\167\155\141\143\163\x79\x6f\x75\x71\171\165\155"]); $this->waqewsckuayqguos("\163\x65\x74\x74\151\156\147\x5f\x6f\160\164\151\x6f\156\x73\x5f\163\141\x76\x65\144", [$this, "\155\x65\153\x6b\x77\155\141\143\163\x79\x6f\x75\x71\171\165\155"]); } public function mekkwmacsyouqyum() { } }
