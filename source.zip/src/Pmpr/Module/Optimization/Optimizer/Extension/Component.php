<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b5b18721             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\x72\x5f\x63\x6f\155\x70\x6f\156\x65\x6e\164\137\143\x68\x61\156\x67\x65\144", [$this, "\x6d\145\x6b\x6b\167\155\141\x63\163\x79\x6f\165\x71\x79\165\x6d"]); $this->waqewsckuayqguos("\163\x65\164\164\151\156\147\x5f\x6f\x70\164\x69\157\x6e\163\x5f\163\x61\166\x65\x64", [$this, "\x6d\x65\x6b\153\167\155\x61\x63\x73\x79\157\165\x71\x79\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\165\x72\147\x65\137\143\x61\x63\x68\145"); } }
