<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f18c2e9c9db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\162\x5f\143\157\x6d\160\x6f\156\145\x6e\164\x5f\x63\x68\x61\156\x67\x65\x64", [$this, "\x6d\x65\153\153\x77\155\141\143\163\171\x6f\x75\x71\x79\165\x6d"]); $this->waqewsckuayqguos("\x73\x65\x74\x74\151\156\x67\x5f\x6f\x70\x74\151\x6f\156\x73\137\x73\x61\166\x65\144", [$this, "\x6d\x65\153\153\167\155\x61\143\x73\171\157\x75\161\x79\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\x75\162\x67\145\x5f\143\x61\143\150\x65"); } }
