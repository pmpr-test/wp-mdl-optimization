<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d002186f7a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\x72\137\143\x6f\155\x70\157\156\x65\x6e\x74\x5f\143\150\x61\156\x67\x65\144", [$this, "\155\145\x6b\153\x77\155\x61\x63\x73\x79\157\x75\161\171\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\164\x74\x69\x6e\x67\137\x6f\x70\x74\151\157\156\163\137\163\141\x76\145\144", [$this, "\x6d\x65\x6b\x6b\x77\155\x61\143\163\171\157\x75\161\x79\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\165\x72\x67\145\137\150\164\155\154\x5f\x63\141\x63\x68\x65"); } }
