<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef5003b08f6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\x70\x72\137\143\x6f\155\160\157\156\x65\156\x74\137\x63\x68\x61\x6e\x67\x65\144", [$this, "\155\145\x6b\x6b\x77\x6d\x61\x63\x73\171\x6f\165\161\171\165\x6d"]); $this->waqewsckuayqguos("\163\145\x74\164\x69\156\x67\137\157\x70\164\x69\x6f\x6e\x73\x5f\163\x61\x76\145\x64", [$this, "\155\145\x6b\153\x77\x6d\x61\x63\163\171\x6f\165\x71\x79\165\155"]); } public function mekkwmacsyouqyum() { } }
