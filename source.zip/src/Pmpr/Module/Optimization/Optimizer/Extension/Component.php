<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76d1d04df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\160\162\137\143\157\155\160\157\156\145\156\x74\137\143\150\141\156\x67\x65\144", [$this, "\155\145\x6b\x6b\x77\x6d\x61\143\163\171\x6f\165\x71\x79\x75\155"]); $this->waqewsckuayqguos("\163\x65\x74\164\x69\156\x67\137\157\x70\x74\151\157\156\163\x5f\x73\141\166\145\144", [$this, "\x6d\x65\x6b\x6b\x77\155\x61\143\x73\171\157\x75\161\171\165\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\x75\x72\x67\x65\x5f\150\x74\155\154\137\143\x61\143\x68\x65"); } }
