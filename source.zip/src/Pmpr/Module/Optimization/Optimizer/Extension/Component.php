<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e86b3a376             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\x72\x5f\x63\x6f\x6d\x70\x6f\156\x65\x6e\x74\x5f\143\150\x61\x6e\x67\x65\x64", [$this, "\155\145\x6b\153\167\x6d\x61\x63\x73\x79\x6f\x75\x71\171\x75\x6d"]); $this->waqewsckuayqguos("\163\x65\164\x74\151\156\147\x5f\157\160\164\x69\157\156\163\137\x73\141\166\x65\x64", [$this, "\x6d\x65\x6b\153\x77\x6d\x61\x63\163\171\157\x75\x71\171\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\x75\162\147\x65\x5f\143\x61\x63\x68\145"); } }
