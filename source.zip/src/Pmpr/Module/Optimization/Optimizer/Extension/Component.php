<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67580826ed61d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\x72\137\x63\157\x6d\160\157\x6e\x65\x6e\164\137\143\x68\x61\x6e\x67\x65\144", [$this, "\155\x65\153\153\x77\x6d\141\143\163\x79\x6f\x75\x71\171\165\x6d"]); $this->waqewsckuayqguos("\163\145\x74\164\151\x6e\147\137\x6f\160\x74\x69\157\156\x73\137\163\141\166\x65\x64", [$this, "\155\x65\x6b\x6b\167\155\141\x63\163\x79\x6f\x75\x71\171\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\x75\x72\147\x65\x5f\150\x74\x6d\154\137\x63\141\x63\x68\x65"); } }
