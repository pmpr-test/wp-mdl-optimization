<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8f0d0713             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\x72\x5f\x63\157\155\160\157\x6e\x65\x6e\x74\137\x63\150\141\x6e\x67\145\x64", [$this, "\x6d\145\x6b\153\167\x6d\x61\143\163\171\x6f\x75\161\x79\x75\155"]); $this->waqewsckuayqguos("\163\145\x74\164\x69\156\147\x5f\x6f\x70\164\151\x6f\x6e\163\x5f\163\141\166\145\x64", [$this, "\155\145\x6b\153\167\155\141\x63\x73\171\157\x75\x71\171\165\x6d"]); } public function mekkwmacsyouqyum() { } }
