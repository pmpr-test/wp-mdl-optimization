<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a47d9207aa3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('pmpr_component_changed', [$this, 'mekkwmacsyouqyum']); $this->waqewsckuayqguos('setting_options_saved', [$this, 'mekkwmacsyouqyum']); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . 'purge_html_cache'); } }
