<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672356236bf3e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\x72\x5f\143\x6f\x6d\160\157\156\x65\x6e\x74\137\x63\x68\x61\x6e\x67\x65\144", [$this, "\155\145\153\x6b\167\x6d\141\x63\163\171\157\x75\x71\171\165\x6d"]); $this->waqewsckuayqguos("\x73\x65\164\164\x69\156\x67\x5f\x6f\x70\x74\x69\x6f\x6e\x73\137\x73\x61\166\x65\144", [$this, "\155\145\x6b\x6b\167\x6d\x61\143\x73\171\x6f\165\x71\171\165\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\165\162\147\145\x5f\150\164\155\x6c\x5f\x63\141\143\150\145"); } }
