<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1377d8db9a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\160\162\x5f\x63\x6f\155\160\157\x6e\145\156\x74\137\x63\x68\x61\156\147\145\x64", [$this, "\155\145\153\x6b\x77\155\x61\x63\163\171\x6f\165\161\171\165\155"]); $this->waqewsckuayqguos("\x73\145\164\164\151\x6e\147\x5f\x6f\x70\164\151\x6f\156\x73\x5f\163\141\x76\x65\x64", [$this, "\x6d\x65\153\x6b\167\155\141\x63\163\171\x6f\165\161\x79\165\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\165\162\x67\145\137\x63\141\143\150\145"); } }
