<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15eb116f20             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\x72\x5f\x63\x6f\x6d\160\157\x6e\145\156\164\137\143\150\x61\156\147\x65\x64", [$this, "\x6d\x65\153\153\167\x6d\141\143\163\x79\157\x75\161\x79\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\164\164\151\156\147\x5f\157\x70\164\151\x6f\156\x73\x5f\x73\x61\x76\x65\x64", [$this, "\x6d\x65\x6b\x6b\x77\155\x61\143\x73\x79\x6f\x75\161\171\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\165\x72\147\x65\x5f\x63\x61\143\150\145"); } }
