<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d840ddfea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\137\143\x6f\x6d\x70\x6f\156\145\156\164\x5f\143\x68\141\x6e\147\145\x64", [$this, "\155\x65\153\x6b\167\155\141\x63\x73\171\157\165\161\x79\x75\155"]); $this->waqewsckuayqguos("\x73\145\x74\x74\151\156\x67\137\x6f\x70\x74\x69\157\x6e\x73\x5f\163\x61\x76\145\x64", [$this, "\155\145\x6b\x6b\x77\x6d\141\x63\163\x79\x6f\x75\161\171\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\165\x72\x67\x65\x5f\143\x61\x63\150\x65"); } }
