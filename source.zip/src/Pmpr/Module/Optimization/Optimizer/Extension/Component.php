<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758102f55148             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\160\x72\137\143\x6f\x6d\160\x6f\x6e\145\156\164\x5f\143\x68\141\156\x67\x65\144", [$this, "\155\x65\x6b\x6b\x77\155\141\x63\163\171\157\x75\161\171\165\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\x74\x69\156\x67\x5f\157\x70\x74\151\157\x6e\163\x5f\x73\141\x76\x65\x64", [$this, "\155\x65\x6b\x6b\167\x6d\141\143\163\x79\157\x75\x71\171\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\x75\162\x67\x65\x5f\x68\x74\x6d\154\x5f\x63\141\x63\150\145"); } }
