<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27a0f7c0c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\x72\137\143\x6f\x6d\160\157\x6e\x65\x6e\164\x5f\143\150\x61\156\x67\145\x64", [$this, "\x6d\145\153\x6b\167\x6d\141\143\163\171\x6f\x75\161\x79\165\x6d"]); $this->waqewsckuayqguos("\x73\145\164\x74\151\156\147\x5f\x6f\x70\x74\151\x6f\x6e\x73\x5f\163\x61\x76\145\144", [$this, "\x6d\x65\x6b\x6b\167\x6d\141\x63\x73\x79\x6f\x75\x71\x79\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\165\162\x67\x65\137\x63\x61\143\x68\x65"); } }
