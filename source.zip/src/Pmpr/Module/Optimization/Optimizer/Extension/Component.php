<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0c5f88d120             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\x72\137\x63\157\155\160\157\156\145\x6e\164\137\143\150\x61\x6e\147\145\144", [$this, "\155\145\153\153\x77\x6d\x61\143\x73\171\x6f\165\x71\x79\165\155"]); $this->waqewsckuayqguos("\x73\x65\164\x74\x69\x6e\147\x5f\x6f\x70\x74\x69\157\156\163\x5f\163\141\x76\x65\x64", [$this, "\155\145\x6b\x6b\x77\x6d\x61\x63\x73\x79\157\165\161\171\165\155"]); } public function mekkwmacsyouqyum() { } }
