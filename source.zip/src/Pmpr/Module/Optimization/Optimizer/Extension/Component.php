<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0c9956f5c6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\x72\137\x63\x6f\x6d\160\x6f\x6e\145\156\x74\x5f\143\150\x61\156\147\145\x64", [$this, "\x6d\145\153\x6b\167\x6d\141\143\163\171\157\x75\x71\x79\x75\x6d"]); $this->waqewsckuayqguos("\163\x65\164\x74\151\x6e\147\x5f\157\160\164\x69\x6f\x6e\x73\x5f\x73\x61\166\145\x64", [$this, "\155\145\x6b\x6b\x77\155\141\x63\163\171\x6f\x75\x71\171\x75\155"]); } public function mekkwmacsyouqyum() { } }
