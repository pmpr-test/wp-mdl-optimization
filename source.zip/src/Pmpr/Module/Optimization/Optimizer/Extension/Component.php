<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f13d321859c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\x70\x72\137\143\157\155\160\157\156\145\x6e\x74\x5f\143\x68\x61\156\147\x65\x64", [$this, "\x6d\x65\153\153\x77\155\141\x63\163\171\157\x75\161\171\165\155"]); $this->waqewsckuayqguos("\163\145\x74\x74\151\156\x67\x5f\157\x70\x74\x69\157\156\x73\137\x73\x61\166\x65\144", [$this, "\x6d\145\x6b\x6b\x77\x6d\x61\143\163\171\x6f\165\x71\x79\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\165\x72\x67\145\137\x63\x61\x63\x68\x65"); } }
