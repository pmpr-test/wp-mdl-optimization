<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb242fc74db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\x72\x5f\x63\157\x6d\x70\157\156\145\156\164\137\143\x68\x61\156\147\145\x64", [$this, "\x6d\145\x6b\x6b\167\x6d\141\143\x73\171\157\165\161\x79\x75\155"]); $this->waqewsckuayqguos("\x73\x65\164\x74\x69\x6e\x67\x5f\157\x70\164\151\157\156\163\137\163\141\166\145\x64", [$this, "\155\145\153\153\167\155\x61\x63\163\x79\157\x75\161\x79\x75\155"]); } public function mekkwmacsyouqyum() { } }
