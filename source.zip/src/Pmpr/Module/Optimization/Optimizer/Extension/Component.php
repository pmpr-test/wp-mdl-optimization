<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f849ccf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\x72\137\x63\x6f\x6d\x70\157\x6e\x65\156\164\137\143\x68\141\x6e\147\x65\x64", [$this, "\155\145\x6b\153\x77\155\141\143\x73\x79\x6f\x75\x71\x79\x75\155"]); $this->waqewsckuayqguos("\x73\145\164\x74\x69\x6e\147\x5f\157\x70\164\151\x6f\156\x73\137\163\141\x76\x65\144", [$this, "\x6d\145\x6b\153\167\155\141\143\x73\171\x6f\x75\x71\x79\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\165\x72\147\145\x5f\x68\164\155\x6c\x5f\143\141\143\150\145"); } }
