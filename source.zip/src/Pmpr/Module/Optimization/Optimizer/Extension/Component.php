<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb25af783f1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\137\x63\x6f\155\x70\x6f\x6e\x65\156\x74\137\143\x68\141\x6e\x67\x65\x64", [$this, "\155\x65\153\153\x77\x6d\x61\x63\x73\171\157\165\161\171\x75\x6d"]); $this->waqewsckuayqguos("\163\145\164\x74\151\156\147\137\x6f\160\x74\151\157\x6e\x73\x5f\163\141\166\145\144", [$this, "\x6d\145\x6b\153\x77\155\x61\143\163\x79\157\165\x71\171\x75\155"]); } public function mekkwmacsyouqyum() { } }
