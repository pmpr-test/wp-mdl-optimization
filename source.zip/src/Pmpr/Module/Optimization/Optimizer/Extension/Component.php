<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb16d680906             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\162\137\143\157\x6d\x70\x6f\x6e\x65\x6e\164\x5f\x63\x68\x61\x6e\147\x65\144", [$this, "\155\145\153\x6b\167\x6d\x61\143\163\171\x6f\165\161\x79\x75\155"]); $this->waqewsckuayqguos("\x73\145\164\x74\x69\x6e\x67\x5f\x6f\160\164\x69\x6f\156\163\137\x73\x61\x76\145\x64", [$this, "\x6d\145\153\x6b\167\155\141\x63\x73\171\x6f\x75\161\x79\165\155"]); } public function mekkwmacsyouqyum() { } }
