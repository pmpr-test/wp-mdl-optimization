<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757fbefa1d87             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\160\x72\137\143\157\x6d\x70\x6f\x6e\x65\x6e\x74\x5f\x63\x68\x61\156\147\145\x64", [$this, "\155\145\153\153\x77\155\x61\143\x73\x79\157\x75\161\x79\165\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\164\151\x6e\x67\137\x6f\x70\x74\151\157\156\x73\137\x73\x61\166\145\x64", [$this, "\x6d\145\x6b\x6b\167\x6d\x61\143\163\x79\x6f\x75\x71\171\165\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\165\162\147\145\137\150\164\x6d\x6c\137\143\141\x63\150\145"); } }
