<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f1c30b6e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\160\162\x5f\x63\x6f\155\160\x6f\x6e\145\156\164\137\143\150\x61\x6e\147\145\144", [$this, "\x6d\145\153\x6b\167\155\x61\143\163\171\157\x75\x71\x79\x75\155"]); $this->waqewsckuayqguos("\x73\x65\x74\x74\x69\x6e\147\x5f\157\x70\x74\151\x6f\156\x73\x5f\x73\x61\166\145\x64", [$this, "\x6d\x65\153\x6b\167\155\x61\143\163\x79\157\165\161\x79\x75\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\165\x72\147\145\137\x68\164\155\x6c\x5f\x63\x61\143\150\x65"); } }
