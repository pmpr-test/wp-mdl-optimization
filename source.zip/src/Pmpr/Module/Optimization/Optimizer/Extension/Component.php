<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec01cb5e285             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\x5f\x63\157\155\160\157\x6e\145\156\x74\x5f\x63\150\x61\156\x67\145\x64", [$this, "\155\145\x6b\153\167\155\x61\x63\163\x79\x6f\x75\x71\x79\x75\155"]); $this->waqewsckuayqguos("\x73\x65\x74\164\x69\x6e\147\x5f\157\160\164\151\157\156\163\x5f\x73\x61\x76\x65\144", [$this, "\155\x65\x6b\153\167\155\x61\143\x73\171\x6f\x75\161\171\x75\155"]); } public function mekkwmacsyouqyum() { } }
