<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f18cb37259d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\160\x72\137\x63\x6f\x6d\160\x6f\x6e\145\156\164\x5f\143\150\x61\x6e\147\145\144", [$this, "\x6d\145\153\x6b\167\155\x61\143\x73\x79\x6f\165\x71\x79\165\x6d"]); $this->waqewsckuayqguos("\163\x65\164\x74\151\x6e\147\x5f\157\160\164\x69\x6f\x6e\x73\x5f\x73\141\166\145\x64", [$this, "\x6d\145\x6b\x6b\x77\155\141\x63\x73\171\157\x75\x71\171\165\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\x75\162\x67\145\x5f\x63\141\x63\x68\145"); } }
