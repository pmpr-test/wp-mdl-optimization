<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf66918980             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\137\x63\x6f\x6d\160\157\156\x65\x6e\x74\x5f\x63\150\x61\156\147\145\x64", [$this, "\x6d\145\x6b\x6b\x77\155\x61\143\x73\x79\157\165\x71\x79\165\x6d"]); $this->waqewsckuayqguos("\163\x65\164\164\151\x6e\147\137\157\160\x74\151\x6f\x6e\x73\137\163\141\166\x65\144", [$this, "\x6d\x65\153\153\x77\155\x61\143\163\171\x6f\x75\161\171\x75\x6d"]); } public function mekkwmacsyouqyum() { } }
