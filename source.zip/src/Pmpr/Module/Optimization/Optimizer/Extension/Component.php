<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1ea51a7c51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\x70\x72\x5f\x63\157\155\160\157\x6e\x65\156\164\137\x63\x68\141\x6e\147\145\x64", [$this, "\x6d\x65\153\153\167\155\x61\143\x73\x79\157\165\x71\171\165\x6d"]); $this->waqewsckuayqguos("\x73\145\164\164\x69\156\147\137\157\160\x74\x69\157\x6e\x73\137\x73\x61\166\x65\144", [$this, "\x6d\145\153\x6b\x77\155\x61\x63\163\171\157\x75\161\x79\165\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\x75\x72\147\x65\x5f\143\x61\143\150\145"); } }
