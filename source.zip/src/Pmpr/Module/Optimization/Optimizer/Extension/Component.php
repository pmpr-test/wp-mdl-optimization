<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb16c082ce5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\x72\x5f\143\157\x6d\160\157\x6e\145\x6e\x74\x5f\x63\150\x61\x6e\x67\145\144", [$this, "\155\x65\x6b\153\167\x6d\x61\x63\163\x79\x6f\x75\x71\x79\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\x74\151\x6e\147\137\x6f\160\x74\x69\157\x6e\163\137\x73\141\x76\145\144", [$this, "\155\x65\x6b\x6b\167\x6d\x61\143\x73\x79\x6f\165\161\171\165\155"]); } public function mekkwmacsyouqyum() { } }
