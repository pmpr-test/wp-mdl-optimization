<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757fc94b167d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\x72\x5f\x63\157\x6d\160\157\156\145\156\x74\x5f\x63\150\141\156\147\x65\144", [$this, "\155\x65\153\153\167\x6d\141\x63\x73\171\x6f\165\x71\x79\165\x6d"]); $this->waqewsckuayqguos("\163\145\164\x74\151\x6e\147\x5f\x6f\x70\x74\x69\157\156\x73\137\x73\141\x76\145\x64", [$this, "\155\x65\x6b\153\x77\x6d\x61\x63\x73\x79\x6f\165\161\171\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\160\x75\x72\147\145\137\x68\164\x6d\x6c\x5f\143\141\143\150\145"); } }
