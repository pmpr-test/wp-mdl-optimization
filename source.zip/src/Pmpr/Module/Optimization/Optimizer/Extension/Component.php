<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e04ea1945             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Optimization; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\155\160\162\x5f\x63\157\x6d\x70\157\156\145\x6e\164\x5f\x63\150\141\156\147\145\x64", [$this, "\x6d\x65\153\153\x77\x6d\x61\143\163\x79\157\x75\x71\x79\165\x6d"]); $this->waqewsckuayqguos("\x73\145\x74\x74\151\156\147\137\x6f\160\164\x69\157\156\x73\x5f\163\141\166\145\x64", [$this, "\155\x65\153\x6b\x77\155\141\x63\x73\171\x6f\x75\161\x79\x75\155"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\x75\x72\x67\x65\137\x63\x61\143\x68\x65"); } }
