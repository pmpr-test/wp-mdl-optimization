<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d980cb95de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; class Component extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\160\x6d\x70\162\137\x63\157\x6d\x70\157\x6e\x65\x6e\164\137\x63\x68\x61\x6e\147\x65\x64", [$this, "\155\145\x6b\153\167\x6d\141\143\x73\x79\x6f\x75\161\x79\x75\155"]); $this->waqewsckuayqguos("\x73\x65\164\x74\151\x6e\x67\137\157\x70\164\x69\x6f\156\163\x5f\x73\x61\x76\145\x64", [$this, "\155\x65\x6b\x6b\x77\155\x61\143\163\171\x6f\x75\x71\x79\165\x6d"]); } public function mekkwmacsyouqyum() { $this->ewcsyqaaigkicgse(Optimization::kgswyesggeyekgmg . "\x70\165\x72\147\x65\137\x68\x74\x6d\154\137\x63\141\x63\150\145"); } }
