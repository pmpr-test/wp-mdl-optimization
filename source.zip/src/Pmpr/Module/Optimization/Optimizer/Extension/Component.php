<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb25ce6cfc8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\155\x70\x72\137\143\x6f\x6d\x70\x6f\156\145\156\x74\137\143\x68\x61\x6e\x67\145\144", [$this, "\155\145\x6b\x6b\x77\x6d\x61\x63\163\171\157\165\x71\x79\x75\x6d"]); $this->waqewsckuayqguos("\x73\145\164\x74\x69\x6e\x67\x5f\x6f\160\164\151\157\156\x73\x5f\163\x61\x76\x65\x64", [$this, "\x6d\145\x6b\x6b\x77\155\141\143\163\x79\x6f\x75\161\x79\x75\x6d"]); } public function mekkwmacsyouqyum() { } }
