<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d3a1360b4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\160\162\137\143\x6f\x6d\160\x6f\156\145\156\x74\137\x63\x68\x61\156\147\145\x64", [$this, "\155\x65\x6b\x6b\167\155\x61\143\163\x79\x6f\x75\161\171\x75\155"]); $this->waqewsckuayqguos("\163\145\x74\x74\151\156\147\x5f\157\x70\164\151\157\x6e\163\x5f\x73\141\166\x65\x64", [$this, "\x6d\145\153\x6b\167\155\x61\x63\163\171\157\x75\x71\171\x75\x6d"]); } public function mekkwmacsyouqyum() { } }
