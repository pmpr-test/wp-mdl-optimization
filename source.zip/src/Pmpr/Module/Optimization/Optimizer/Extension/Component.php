<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a8053cce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Extension; class Component extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x70\x6d\x70\162\137\143\157\x6d\x70\157\x6e\x65\156\x74\x5f\143\150\x61\156\147\x65\144", [$this, "\x6d\145\153\153\x77\155\x61\143\x73\171\157\x75\161\x79\165\155"]); $this->waqewsckuayqguos("\163\145\164\x74\151\156\x67\137\157\x70\164\x69\x6f\x6e\x73\137\x73\x61\166\x65\x64", [$this, "\155\145\153\153\x77\155\141\143\163\171\x6f\165\161\171\165\155"]); } public function mekkwmacsyouqyum() { } }
