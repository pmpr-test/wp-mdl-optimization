<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f849ccf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; class Asset extends Common { public function mameiwsayuyquoeq() { CriticalCSS::symcgieuakksimmu(); if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto ewiwaeckgqaiwgio; } Setting::symcgieuakksimmu(); goto qmwmasuoyuwmcigw; ewiwaeckgqaiwgio: Preload::symcgieuakksimmu(); switch ($this->weysguygiseoukqw(Setting::acmmwemggiumsoyo)) { case Setting::gwgekowoowwyuuia: case Setting::oqiaceqksggqgoww: Delay::symcgieuakksimmu(); goto oqkcuegyumswqekg; case Setting::suqaaeokeaqayoyk: Defer::symcgieuakksimmu(); goto oqkcuegyumswqekg; } wcgoiisqmmawuiag: oqkcuegyumswqekg: qmwmasuoyuwmcigw: } }
