<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b5b18721             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; class Asset extends Common { public function mameiwsayuyquoeq() { CriticalCSS::symcgieuakksimmu(); if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto ueeowyociayoygsa; } Setting::symcgieuakksimmu(); goto isumwussqyqawwmy; ueeowyociayoygsa: Preload::symcgieuakksimmu(); switch ($this->weysguygiseoukqw(Setting::acmmwemggiumsoyo)) { case Setting::gwgekowoowwyuuia: case Setting::oqiaceqksggqgoww: Delay::symcgieuakksimmu(); goto isssemmuiiaewiwi; case Setting::suqaaeokeaqayoyk: Defer::symcgieuakksimmu(); goto isssemmuiiaewiwi; } oiguycsiaweycioe: isssemmuiiaewiwi: isumwussqyqawwmy: } }
