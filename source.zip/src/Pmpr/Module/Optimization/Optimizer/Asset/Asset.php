<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76d1d04df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; class Asset extends Common { public function mameiwsayuyquoeq() { CriticalCSS::symcgieuakksimmu(); if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto wcgoiisqmmawuiag; } Setting::symcgieuakksimmu(); goto ewiwaeckgqaiwgio; wcgoiisqmmawuiag: Preload::symcgieuakksimmu(); switch ($this->weysguygiseoukqw(Setting::acmmwemggiumsoyo)) { case Setting::gwgekowoowwyuuia: case Setting::oqiaceqksggqgoww: Delay::symcgieuakksimmu(); goto ekwmcssqowkcoyci; case Setting::suqaaeokeaqayoyk: Defer::symcgieuakksimmu(); goto ekwmcssqowkcoyci; } oqkcuegyumswqekg: ekwmcssqowkcoyci: ewiwaeckgqaiwgio: } }
