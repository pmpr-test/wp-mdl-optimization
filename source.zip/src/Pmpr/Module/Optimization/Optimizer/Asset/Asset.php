<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705177f65977             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; class Asset extends Common { public function mameiwsayuyquoeq() { CriticalCSS::symcgieuakksimmu(); if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto isssemmuiiaewiwi; } Preload::symcgieuakksimmu(); switch ($this->weysguygiseoukqw(Setting::acmmwemggiumsoyo)) { case Setting::gwgekowoowwyuuia: case Setting::oqiaceqksggqgoww: Delay::symcgieuakksimmu(); goto muaigwwqgsgowgkk; case Setting::suqaaeokeaqayoyk: Defer::symcgieuakksimmu(); goto muaigwwqgsgowgkk; } imgyqyeaoawqscae: muaigwwqgsgowgkk: isssemmuiiaewiwi: } }
