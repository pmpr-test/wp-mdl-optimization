<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6884a917ee441             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; use Pmpr\Module\Optimization\Container; class Asset extends Container { public function mameiwsayuyquoeq() { CriticalCSS::symcgieuakksimmu(); if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { Preload::symcgieuakksimmu(); switch ($this->weysguygiseoukqw(Setting::acmmwemggiumsoyo)) { case Setting::gwgekowoowwyuuia: case Setting::oqiaceqksggqgoww: Delay::symcgieuakksimmu(); break; case Setting::suqaaeokeaqayoyk: Defer::symcgieuakksimmu(); break; } } } }
