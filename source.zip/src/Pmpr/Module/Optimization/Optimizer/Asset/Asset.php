<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1ea51a7c51             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Asset; class Asset extends Common { public function mameiwsayuyquoeq() { CriticalCSS::symcgieuakksimmu(); if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto muaigwwqgsgowgkk; } Setting::symcgieuakksimmu(); goto imgyqyeaoawqscae; muaigwwqgsgowgkk: Preload::symcgieuakksimmu(); switch ($this->weysguygiseoukqw(Setting::acmmwemggiumsoyo)) { case Setting::gwgekowoowwyuuia: case Setting::oqiaceqksggqgoww: Delay::symcgieuakksimmu(); goto miiegqgiuamasook; case Setting::suqaaeokeaqayoyk: Defer::symcgieuakksimmu(); goto miiegqgiuamasook; } eskmkooukwwieuke: miiegqgiuamasook: imgyqyeaoawqscae: } }
