<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a588a282a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Buffer; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Optimizer\Common; abstract class Engine extends Common { const scskcyisyowcuagq = Optimization::kgswyesggeyekgmg . "\142\x75\x66\x66\145\x72\x5f\160\x72\157\143\x65\x73\163"; public final function miasamwyaiagioug($ekiuyucoiagmscgy, int $sqqewmoeaekuyyas = 10) : self { $this->aqaqisyssqeomwom(self::scskcyisyowcuagq, $ekiuyucoiagmscgy, $sqqewmoeaekuyyas); return $this; } public function uakokyiygeukkwyq($sociqikgoyemqaac) { return preg_replace("\x2f\x3c\41\x2d\55\x28\x2e\x2a\51\55\55\x3e\57\x55\x69\163", '', $sociqikgoyemqaac); } }
