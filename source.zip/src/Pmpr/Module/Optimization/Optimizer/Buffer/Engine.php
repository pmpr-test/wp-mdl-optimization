<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c4541eb2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Buffer; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; abstract class Engine extends Container { const scskcyisyowcuagq = Optimization::kgswyesggeyekgmg . "\142\x75\146\146\x65\162\x5f\160\x72\x6f\143\x65\x73\163"; public final function miasamwyaiagioug($ekiuyucoiagmscgy, int $sqqewmoeaekuyyas = 10) : self { $this->aqaqisyssqeomwom(self::scskcyisyowcuagq, $ekiuyucoiagmscgy, $sqqewmoeaekuyyas); return $this; } public function uakokyiygeukkwyq($sociqikgoyemqaac) { return preg_replace("\x2f\x3c\x21\55\x2d\50\56\x2a\x29\x2d\x2d\76\57\125\x69\163", '', $sociqikgoyemqaac); } }
