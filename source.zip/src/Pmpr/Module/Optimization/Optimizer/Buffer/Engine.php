<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581596084c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Buffer; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; abstract class Engine extends Container { const scskcyisyowcuagq = Optimization::kgswyesggeyekgmg . "\142\165\146\146\145\x72\137\160\x72\x6f\143\x65\163\163"; public final function miasamwyaiagioug($ekiuyucoiagmscgy, int $sqqewmoeaekuyyas = 10) : self { $this->aqaqisyssqeomwom(self::scskcyisyowcuagq, $ekiuyucoiagmscgy, $sqqewmoeaekuyyas); return $this; } public function uakokyiygeukkwyq($sociqikgoyemqaac) { return preg_replace("\57\x3c\41\55\55\x28\56\x2a\51\55\x2d\x3e\57\125\151\163", '', $sociqikgoyemqaac); } }
