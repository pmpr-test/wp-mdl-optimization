<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758088a59167             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Buffer; use Pmpr\Module\Optimization\Container; use Pmpr\Module\Optimization\Optimization; abstract class Engine extends Container { const scskcyisyowcuagq = Optimization::kgswyesggeyekgmg . "\x62\165\x66\146\145\162\137\160\162\157\143\x65\x73\x73"; public final function miasamwyaiagioug($ekiuyucoiagmscgy, int $sqqewmoeaekuyyas = 10) : self { $this->aqaqisyssqeomwom(self::scskcyisyowcuagq, $ekiuyucoiagmscgy, $sqqewmoeaekuyyas); return $this; } public function uakokyiygeukkwyq($sociqikgoyemqaac) { return preg_replace("\57\74\41\x2d\55\50\x2e\52\51\x2d\55\76\57\x55\151\163", '', $sociqikgoyemqaac); } }
