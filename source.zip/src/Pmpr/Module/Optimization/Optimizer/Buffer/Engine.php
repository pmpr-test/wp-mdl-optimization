<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eafa4785061             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Buffer; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Optimizer\Common; abstract class Engine extends Common { const scskcyisyowcuagq = Optimization::kgswyesggeyekgmg . "\x62\165\146\146\145\162\x5f\x70\x72\157\143\145\x73\163"; public final function miasamwyaiagioug($ekiuyucoiagmscgy, int $sqqewmoeaekuyyas = 10) : self { $this->aqaqisyssqeomwom(self::scskcyisyowcuagq, $ekiuyucoiagmscgy, $sqqewmoeaekuyyas); return $this; } public function uakokyiygeukkwyq($sociqikgoyemqaac) { return preg_replace("\x2f\74\41\55\55\x28\x2e\x2a\x29\55\x2d\76\57\125\x69\x73", '', $sociqikgoyemqaac); } }
