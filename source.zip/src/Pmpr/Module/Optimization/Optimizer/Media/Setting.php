<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a1764bb6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\x64\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\x7a\x79\137\154\157\x61\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\141\147\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\162\x61\155\145\137\141\156\x64\x5f\x76\x69\x64\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\144\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\x74\x69\x6d\x69\172\x65\40\x69\155\141\147\145\54\40\166\151\x64\x65\40\x61\156\x64\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
