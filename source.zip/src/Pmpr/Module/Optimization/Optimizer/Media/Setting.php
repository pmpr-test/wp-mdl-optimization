<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec01cb5e285             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\x64\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\172\x79\137\154\157\x61\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\x61\x67\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\162\x61\155\x65\137\x61\156\x64\x5f\166\151\x64\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\x69\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\x74\x69\155\151\172\145\x20\151\x6d\141\x67\x65\54\x20\x76\x69\144\145\x20\x61\x6e\144\40\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
