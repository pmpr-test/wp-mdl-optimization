<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f134058bae5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\x69\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\x7a\x79\x5f\154\x6f\x61\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\141\147\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\x72\141\155\145\137\x61\156\x64\137\x76\151\144\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\x64\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\144\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\x74\151\x6d\151\172\x65\x20\151\x6d\141\147\145\54\40\x76\x69\x64\x65\x20\x61\x6e\144\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
