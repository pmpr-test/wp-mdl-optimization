<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f18cb37259d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\144\151\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\x7a\x79\137\x6c\157\141\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\x61\147\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\162\x61\x6d\145\x5f\x61\156\x64\x5f\x76\151\x64\x65\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\x74\151\155\x69\x7a\x65\x20\x69\x6d\141\x67\x65\54\40\x76\x69\144\145\40\x61\x6e\144\x20\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
