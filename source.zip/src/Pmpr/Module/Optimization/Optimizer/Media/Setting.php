<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d3a1360b4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\144\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\x7a\171\137\x6c\x6f\x61\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\x61\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\162\141\x6d\145\x5f\141\156\144\137\x76\151\x64\x65\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\144\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\x74\x69\x6d\151\x7a\x65\40\x69\155\141\147\x65\54\40\x76\x69\144\x65\x20\x61\x6e\x64\40\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
