<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27a0f7c0c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\144\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\x7a\171\x5f\x6c\x6f\x61\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\x61\x67\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\x72\141\155\145\x5f\141\x6e\144\x5f\166\151\x64\145\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\144\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\x74\x69\x6d\151\172\145\40\151\x6d\x61\x67\145\54\40\x76\x69\144\145\40\141\x6e\x64\40\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
