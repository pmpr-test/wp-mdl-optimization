<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f15e8e06c9b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\144\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\x7a\x79\x5f\x6c\x6f\141\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\x61\147\x65\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\x72\x61\x6d\x65\137\141\156\144\x5f\166\x69\144\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\x64\151\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\x74\x69\155\151\x7a\x65\40\151\155\141\x67\145\54\x20\x76\151\144\x65\40\141\156\x64\x20\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
