<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1342030351             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\x64\151\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\172\171\137\154\x6f\x61\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\141\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\x72\x61\155\145\137\141\156\x64\x5f\166\x69\x64\145\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\151\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\x74\x69\155\x69\x7a\x65\x20\x69\x6d\141\147\x65\54\40\166\151\144\x65\40\x61\156\x64\40\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
