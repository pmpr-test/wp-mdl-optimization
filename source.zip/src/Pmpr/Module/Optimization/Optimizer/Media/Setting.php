<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae19a7b618             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\x65\x64\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\172\x79\137\x6c\x6f\141\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\x61\x67\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\x72\x61\x6d\145\x5f\141\x6e\144\137\166\x69\x64\145\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\x64\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\x64\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\x74\x69\x6d\151\x7a\145\x20\x69\155\x61\147\145\x2c\40\x76\x69\144\145\40\x61\156\144\x20\56\56\x2e", PR__MDL__OPTIMIZATION))); } }
