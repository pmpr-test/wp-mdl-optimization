<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a60d5dfe2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\x69\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\172\171\x5f\154\x6f\141\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\x67\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\162\141\x6d\145\x5f\141\156\x64\x5f\166\x69\x64\145\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\x64\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\144\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\151\155\151\x7a\x65\40\151\x6d\141\147\145\54\40\x76\x69\x64\x65\40\x61\156\x64\40\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
