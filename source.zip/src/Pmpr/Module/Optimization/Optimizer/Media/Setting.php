<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e29caf530             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\x64\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\172\171\137\154\x6f\x61\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\x61\x67\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\x72\141\x6d\145\137\141\156\144\x5f\166\151\x64\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\x64\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\144\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\164\151\x6d\x69\172\145\40\151\x6d\141\147\145\54\x20\x76\x69\144\145\40\x61\x6e\x64\40\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
