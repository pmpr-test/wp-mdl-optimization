<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a8053cce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\x64\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\172\171\x5f\154\x6f\x61\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\x61\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\x72\141\x6d\145\137\x61\156\x64\x5f\166\151\x64\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\x64\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\x74\x69\155\x69\172\145\x20\151\155\x61\x67\145\54\x20\x76\151\x64\145\40\x61\156\144\40\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
