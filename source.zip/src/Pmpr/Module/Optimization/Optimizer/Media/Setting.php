<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf66918980             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\144\151\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\x61\172\x79\x5f\154\x6f\141\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\141\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\162\x61\155\145\x5f\x61\156\x64\x5f\166\x69\144\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\145\144\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\145\144\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\x74\x69\x6d\x69\x7a\145\x20\151\155\141\147\x65\x2c\40\x76\151\x64\145\40\141\156\144\x20\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
