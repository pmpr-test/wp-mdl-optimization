<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb25ce6cfc8             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\144\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\172\171\x5f\154\x6f\141\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\x6d\x61\x67\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\x69\146\162\x61\155\x65\x5f\141\156\144\137\x76\x69\x64\x65\157\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\144\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\144\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\x70\x74\151\x6d\x69\172\145\40\151\x6d\141\147\145\54\x20\166\x69\x64\145\40\141\x6e\144\40\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
