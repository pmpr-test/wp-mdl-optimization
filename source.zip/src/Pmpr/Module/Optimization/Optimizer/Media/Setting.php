<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec08ff06dc0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\151\141\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\141\172\171\x5f\154\157\141\x64\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\x6d\141\147\145\163"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\x72\141\x6d\145\137\141\156\144\x5f\166\151\x64\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\x65\144\151\141")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\x64\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\x74\x69\155\x69\x7a\x65\x20\x69\155\x61\147\x65\54\x20\166\151\144\x65\40\x61\x6e\x64\x20\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
