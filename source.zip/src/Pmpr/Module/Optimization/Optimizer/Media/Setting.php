<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0c5f88d120             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\145\x64\x69\x61\x5f"; const meciimymegqueigk = self::aqywkwyscogcecei . "\154\141\172\171\x5f\x6c\x6f\x61\144\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\x61\147\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\162\141\155\145\137\141\156\x64\137\166\151\x64\145\x6f\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\145\x64\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\160\x74\x69\155\x69\172\x65\x20\151\x6d\141\x67\x65\x2c\40\x76\151\144\145\40\x61\x6e\144\40\x2e\x2e\56", PR__MDL__OPTIMIZATION))); } }
