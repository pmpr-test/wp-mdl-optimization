<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb242fc74db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\155\x65\x64\151\x61\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\172\x79\x5f\154\157\x61\144\137"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\151\155\x61\147\145\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\146\162\x61\155\145\x5f\141\156\144\x5f\166\x69\144\x65\157\x73"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x6d\x65\144\151\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\x4d\x65\x64\x69\141", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\117\x70\164\151\x6d\x69\172\145\40\151\x6d\141\147\x65\54\40\x76\x69\144\x65\x20\x61\x6e\x64\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
