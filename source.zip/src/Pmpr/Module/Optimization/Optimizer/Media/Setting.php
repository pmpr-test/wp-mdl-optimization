<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb16c082ce5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { const aqywkwyscogcecei = "\x6d\145\144\x69\141\137"; const meciimymegqueigk = self::aqywkwyscogcecei . "\x6c\x61\x7a\171\x5f\x6c\157\x61\x64\x5f"; const uwgswmisuuigoucw = self::meciimymegqueigk . "\x69\155\x61\x67\x65\x73"; const gowiqmkskqiqsgsc = self::meciimymegqueigk . "\151\x66\162\x61\155\145\x5f\141\x6e\144\137\x76\x69\144\x65\x6f\163"; public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\155\145\144\x69\x61")->jyumyyugiwwiqomk(20)->gswweykyogmsyawy(__("\115\x65\x64\x69\x61", PR__MDL__OPTIMIZATION))->saemoowcasogykak(IconInterface::eeycgeueeukoscmu)->gucwmccyimoagwcm(__("\x4f\160\164\151\155\x69\x7a\145\40\151\x6d\x61\147\145\x2c\x20\166\151\x64\x65\x20\x61\x6e\x64\x20\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
