<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f13d321859c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; use Pmpr\Module\Optimization\Optimizer\Media\Common as BaseClass; abstract class Common extends BaseClass { }
