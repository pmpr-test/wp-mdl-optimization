<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e68d3d663             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; class LazyLoad extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto yaumwqeommqigswq; } if (!$this->weysguygiseoukqw(Setting::owqmaigscwikmwgg)) { goto wsqiqkiucakewgou; } Engine::symcgieuakksimmu(); wsqiqkiucakewgou: goto wiiqigwgyuiuksia; yaumwqeommqigswq: Setting::symcgieuakksimmu(); wiiqigwgyuiuksia: } }
