<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76d1d04df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; class LazyLoad extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto gsgkayokisiesciy; } if (!$this->weysguygiseoukqw(Setting::owqmaigscwikmwgg)) { goto kkwqmewaksmokuqy; } Engine::symcgieuakksimmu(); kkwqmewaksmokuqy: goto ascogkesqmuuaesq; gsgkayokisiesciy: Setting::symcgieuakksimmu(); ascogkesqmuuaesq: } }
