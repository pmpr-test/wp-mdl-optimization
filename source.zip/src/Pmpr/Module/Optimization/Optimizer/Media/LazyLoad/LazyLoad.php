<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f849ccf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; class LazyLoad extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto ascogkesqmuuaesq; } if (!$this->weysguygiseoukqw(Setting::owqmaigscwikmwgg)) { goto gsgkayokisiesciy; } Engine::symcgieuakksimmu(); gsgkayokisiesciy: goto askukaucmocewkgg; ascogkesqmuuaesq: Setting::symcgieuakksimmu(); askukaucmocewkgg: } }
