<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132909708a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; class LazyLoad extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto syykqmkiyoekqsek; } if (!$this->weysguygiseoukqw(Setting::owqmaigscwikmwgg)) { goto sqmqwqeoygcmqcim; } Engine::symcgieuakksimmu(); sqmqwqeoygcmqcim: goto aiqekkyauwswayyq; syykqmkiyoekqsek: Setting::symcgieuakksimmu(); aiqekkyauwswayyq: } }
