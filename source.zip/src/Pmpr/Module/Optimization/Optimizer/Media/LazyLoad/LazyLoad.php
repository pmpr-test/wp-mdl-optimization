<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2b472f16c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\LazyLoad; class LazyLoad extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto mcmkqgkwyqoiikcq; } if (!$this->weysguygiseoukqw(Setting::owqmaigscwikmwgg)) { goto aiukiwqmikscoswm; } Engine::symcgieuakksimmu(); aiukiwqmikscoswm: goto ssyukuseoymackeo; mcmkqgkwyqoiikcq: Setting::symcgieuakksimmu(); ssyukuseoymackeo: } }
