<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705177f65977             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Module\Optimization\Optimizer\Common; use Pmpr\Module\Optimization\Optimizer\Media\ImageDimension\ImageDimension; use Pmpr\Module\Optimization\Optimizer\Media\LazyLoad\LazyLoad; use Pmpr\Module\Optimization\Optimizer\Media\LazyLoad\Setting as LazyLoadSetting; use Pmpr\Module\Optimization\Optimizer\Media\ImageDimension\Setting as ImageDimensionSetting; class Media extends Common { public function mameiwsayuyquoeq() { if (!$this->weysguygiseoukqw(LazyLoadSetting::owqmaigscwikmwgg)) { goto ywsywoumuaykkeaa; } LazyLoad::symcgieuakksimmu(); ywsywoumuaykkeaa: if (!$this->weysguygiseoukqw(ImageDimensionSetting::issekcywqmgcacqc)) { goto wsqiqkiucakewgou; } ImageDimension::symcgieuakksimmu(); wsqiqkiucakewgou: } }
