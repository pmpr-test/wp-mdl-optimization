<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76d1d04df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; class ImageDimension extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto acaeigkmigikeuyu; } if (!$this->weysguygiseoukqw(Setting::issekcywqmgcacqc)) { goto mciumqyyossyiuyk; } Engine::symcgieuakksimmu(); mciumqyyossyiuyk: goto kqyeukywmgismyaq; acaeigkmigikeuyu: Setting::symcgieuakksimmu(); kqyeukywmgismyaq: } }
