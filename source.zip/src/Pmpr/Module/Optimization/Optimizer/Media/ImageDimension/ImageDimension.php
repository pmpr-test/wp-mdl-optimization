<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec01cb5e285             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; class ImageDimension extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto ywokggauuiosegog; } if (!$this->weysguygiseoukqw(Setting::issekcywqmgcacqc)) { goto yqqseqskcqeqkacm; } Engine::symcgieuakksimmu(); yqqseqskcqeqkacm: goto uoewiggumomegksg; ywokggauuiosegog: Setting::symcgieuakksimmu(); uoewiggumomegksg: } }
