<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e29caf530             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; class ImageDimension extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto kuuawiosmkgqsscy; } if (!$this->weysguygiseoukqw(Setting::issekcywqmgcacqc)) { goto saiuoomgskwgyeya; } Engine::symcgieuakksimmu(); saiuoomgskwgyeya: goto kwocaqggwcksesce; kuuawiosmkgqsscy: Setting::symcgieuakksimmu(); kwocaqggwcksesce: } }
