<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8f0d0713             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; class ImageDimension extends Common { public function mameiwsayuyquoeq() { Setting::symcgieuakksimmu(); if (!($this->weysguygiseoukqw(Setting::issekcywqmgcacqc) && $this->isgmmgcaqsguwias()->asgqmkcukouykiie()->ocysssyiuaueqiei())) { goto akkmaiaiamyaikqe; } Engine::symcgieuakksimmu(); akkmaiaiamyaikqe: } }
