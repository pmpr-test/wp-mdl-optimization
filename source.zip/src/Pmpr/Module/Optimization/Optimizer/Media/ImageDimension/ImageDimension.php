<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa7f849ccf2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; class ImageDimension extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto kqyeukywmgismyaq; } if (!$this->weysguygiseoukqw(Setting::issekcywqmgcacqc)) { goto acaeigkmigikeuyu; } Engine::symcgieuakksimmu(); acaeigkmigikeuyu: goto mukwsuuuqcgesmwc; kqyeukywmgismyaq: Setting::symcgieuakksimmu(); mukwsuuuqcgesmwc: } }
