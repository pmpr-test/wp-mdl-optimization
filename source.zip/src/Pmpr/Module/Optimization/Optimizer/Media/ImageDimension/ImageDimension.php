<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a60d5dfe2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; class ImageDimension extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto aucwccaiqwsmyuaq; } if (!$this->weysguygiseoukqw(Setting::issekcywqmgcacqc)) { goto bgakaasgwwygosyi; } Engine::symcgieuakksimmu(); bgakaasgwwygosyi: goto agyooskogigyayws; aucwccaiqwsmyuaq: Setting::symcgieuakksimmu(); agyooskogigyayws: } }
