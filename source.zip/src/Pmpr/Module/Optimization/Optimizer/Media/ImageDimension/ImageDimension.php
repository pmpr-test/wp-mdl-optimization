<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f132909708a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media\ImageDimension; class ImageDimension extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto mcagemacuqyskogs; } if (!$this->weysguygiseoukqw(Setting::issekcywqmgcacqc)) { goto ossakckwskyqusmm; } Engine::symcgieuakksimmu(); ossakckwskyqusmm: goto aamgqoqyyooimqkm; mcagemacuqyskogs: Setting::symcgieuakksimmu(); aamgqoqyyooimqkm: } }
