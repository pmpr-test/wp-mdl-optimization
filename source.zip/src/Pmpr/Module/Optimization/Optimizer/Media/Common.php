<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec78c96fd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\Media; use Pmpr\Module\Optimization\Optimizer\Common as BaseClass; abstract class Common extends BaseClass { }
