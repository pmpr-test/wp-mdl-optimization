<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76d1d04df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(6)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\x54\115\114\x20\115\141\156\141\147\145\x6d\145\x6e\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\145\141\x6e\165\160\54\x20\115\x69\x6e\151\146\171\40\141\x6e\144\40\56\56\56", PR__MDL__OPTIMIZATION))); } }
