<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a60d5dfe2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(6)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\124\x4d\x4c\40\x4d\x61\156\141\147\x65\155\145\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\154\x65\141\156\x75\x70\54\40\x4d\151\x6e\151\x66\171\x20\141\156\x64\40\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
