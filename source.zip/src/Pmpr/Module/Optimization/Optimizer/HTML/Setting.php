<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757fc94b167d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\HTML\Error\Setting as ErrorSetting; use Pmpr\Module\Optimization\Optimizer\HTML\Minify\Setting as MinifySetting; use Pmpr\Module\Optimization\Optimizer\HTML\Cleanup\Setting as CleanupSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { ErrorSetting::symcgieuakksimmu(); MinifySetting::symcgieuakksimmu(); CleanupSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(6)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\124\115\114\40\x4d\x61\156\x61\x67\145\x6d\x65\x6e\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x6c\145\141\156\165\x70\54\40\x4d\151\156\151\x66\171\x20\x61\156\x64\x20\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
