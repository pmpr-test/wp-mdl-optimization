<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758114e5f226             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\HTML\Error\Setting as ErrorSetting; use Pmpr\Module\Optimization\Optimizer\HTML\Minify\Setting as MinifySetting; use Pmpr\Module\Optimization\Optimizer\HTML\Cleanup\Setting as CleanupSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { ErrorSetting::symcgieuakksimmu(); MinifySetting::symcgieuakksimmu(); CleanupSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(6)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\x54\x4d\114\x20\115\141\x6e\141\147\145\x6d\145\x6e\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\x65\x61\156\165\160\54\x20\115\x69\x6e\x69\x66\171\x20\x61\156\x64\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
