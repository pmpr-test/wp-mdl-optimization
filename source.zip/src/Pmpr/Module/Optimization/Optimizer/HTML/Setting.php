<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae19a7b618             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\x54\115\x4c\x20\x4d\x61\156\141\147\x65\x6d\145\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\x65\x61\156\165\160\54\40\x4d\x69\x6e\151\146\171\40\141\x6e\144\x20\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
