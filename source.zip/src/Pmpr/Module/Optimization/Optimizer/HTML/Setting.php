<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd9008d45             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\HTML\Error\Setting as ErrorSetting; use Pmpr\Module\Optimization\Optimizer\HTML\Minify\Setting as MinifySetting; use Pmpr\Module\Optimization\Optimizer\HTML\Cleanup\Setting as CleanupSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { ErrorSetting::symcgieuakksimmu(); MinifySetting::symcgieuakksimmu(); CleanupSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(6)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\x54\x4d\x4c\x20\x4d\x61\156\x61\x67\x65\155\145\x6e\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x6c\145\x61\156\165\160\54\40\x4d\151\x6e\x69\146\x79\40\x61\156\144\x20\x2e\56\56", PR__MDL__OPTIMIZATION))); } }
