<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4b1fa9ac4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\HTML\Error\Setting as ErrorSetting; use Pmpr\Module\Optimization\Optimizer\HTML\Minify\Setting as MinifySetting; use Pmpr\Module\Optimization\Optimizer\HTML\Cleanup\Setting as CleanupSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { ErrorSetting::symcgieuakksimmu(); MinifySetting::symcgieuakksimmu(); CleanupSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(6)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\110\124\x4d\x4c\40\115\x61\x6e\141\x67\x65\x6d\x65\x6e\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\145\141\x6e\x75\x70\54\40\115\x69\156\x69\146\171\x20\141\156\144\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
