<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e04ea1945             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(6)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\110\124\115\x4c\x20\115\141\x6e\141\147\145\155\x65\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x6c\145\141\x6e\x75\x70\54\x20\x4d\x69\156\151\146\171\x20\141\x6e\144\40\56\x2e\56", PR__MDL__OPTIMIZATION))); } }
