<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7aea357a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\110\x54\x4d\x4c\40\115\141\156\141\147\145\155\145\156\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\145\141\156\x75\160\x2c\40\115\151\x6e\x69\146\x79\x20\x61\x6e\144\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
