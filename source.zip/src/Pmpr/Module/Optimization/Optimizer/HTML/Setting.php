<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d3a1360b4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\110\x54\115\114\x20\x4d\141\156\x61\147\x65\x6d\x65\x6e\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x6c\145\x61\x6e\x75\x70\x2c\x20\x4d\x69\156\x69\x66\x79\x20\141\x6e\144\40\x2e\56\x2e", PR__MDL__OPTIMIZATION))); } }
