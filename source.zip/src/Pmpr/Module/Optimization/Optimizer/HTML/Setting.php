<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68855d3d0b32c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\Optimizer\HTML\Error\Setting as ErrorSetting; use Pmpr\Module\Optimization\Optimizer\HTML\Minify\Setting as MinifySetting; use Pmpr\Module\Optimization\Optimizer\HTML\Cleanup\Setting as CleanupSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { ErrorSetting::symcgieuakksimmu(); MinifySetting::symcgieuakksimmu(); CleanupSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->ogimmkwaymekmoky($uuyucgkyusckoaeq->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(6)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__('HTML Management', PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__('Cleanup, Minify and ...', PR__MDL__OPTIMIZATION))); } }
