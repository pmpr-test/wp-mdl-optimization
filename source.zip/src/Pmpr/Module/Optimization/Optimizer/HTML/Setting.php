<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e68d3d663             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(6)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\110\x54\x4d\114\x20\115\x61\156\x61\x67\x65\155\x65\156\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x6c\145\x61\x6e\x75\160\x2c\40\x4d\x69\156\x69\x66\171\40\x61\x6e\144\x20\x2e\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
