<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f13d321859c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\124\115\x4c\40\x4d\x61\156\141\147\145\155\x65\x6e\x74", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x6c\x65\x61\156\165\x70\54\40\115\151\156\x69\x66\x79\x20\x61\156\144\x20\56\56\56", PR__MDL__OPTIMIZATION))); } }
