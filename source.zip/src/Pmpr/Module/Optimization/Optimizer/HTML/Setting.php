<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4c436ce06             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg(Constants::gsqoooskigukokks)->jyumyyugiwwiqomk(5)->saemoowcasogykak(IconInterface::yeuisqamqouiquyu)->gswweykyogmsyawy(__("\x48\124\x4d\114\40\115\141\x6e\141\147\x65\155\x65\x6e\164", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\154\x65\x61\156\165\160\x2c\40\x4d\x69\x6e\151\x66\171\40\141\156\144\40\56\x2e\x2e", PR__MDL__OPTIMIZATION))); } }
