<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1377d8db9a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Cleanup; use Pmpr\Module\Optimization\Optimizer\HTML\Common as BaseClass; abstract class Common extends BaseClass { }
