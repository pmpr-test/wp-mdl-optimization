<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef4dfc43710             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Cleanup; class Cleanup extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto ossyqogewmggmaoc; } Engine::symcgieuakksimmu(); goto ggkoiouwecyiosym; ossyqogewmggmaoc: Setting::symcgieuakksimmu(); ggkoiouwecyiosym: } }
