<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1342030351             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Cleanup; class Cleanup extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto cycyaqqawmwiywwe; } Engine::symcgieuakksimmu(); goto ckowiuagwmsqmiqc; cycyaqqawmwiywwe: Setting::symcgieuakksimmu(); ckowiuagwmsqmiqc: } }
