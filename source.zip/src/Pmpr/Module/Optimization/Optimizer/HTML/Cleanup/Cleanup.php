<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76d1d04df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Cleanup; class Cleanup extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto kmocamaieycogugg; } Engine::symcgieuakksimmu(); goto iuieyqacggsykgus; kmocamaieycogugg: Setting::symcgieuakksimmu(); iuieyqacggsykgus: } }
