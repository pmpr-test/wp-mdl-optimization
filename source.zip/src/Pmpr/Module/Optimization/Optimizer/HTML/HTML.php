<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec78c96fd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML; use Pmpr\Module\Optimization\Optimizer\HTML\Cleanup\Cleanup; use Pmpr\Module\Optimization\Optimizer\HTML\Error\Error; use Pmpr\Module\Optimization\Optimizer\HTML\Minify\Minify; class HTML extends Common { public function mameiwsayuyquoeq() { Error::symcgieuakksimmu(); Minify::symcgieuakksimmu(); Cleanup::symcgieuakksimmu(); Setting::symcgieuakksimmu(); } }
