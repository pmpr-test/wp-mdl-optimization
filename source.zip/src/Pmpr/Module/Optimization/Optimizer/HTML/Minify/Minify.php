<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a588a282a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; class Minify extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto caoikoqmyeqsqqqe; } HTML::symcgieuakksimmu(); Style::symcgieuakksimmu(); Script::symcgieuakksimmu(); goto moimkkmkooeiyisc; caoikoqmyeqsqqqe: Setting::symcgieuakksimmu(); moimkkmkooeiyisc: } }
