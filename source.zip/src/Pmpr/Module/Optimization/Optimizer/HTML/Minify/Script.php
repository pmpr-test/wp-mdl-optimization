<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf66918980             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; use MatthiasMullie\Minify\JS; use Pmpr\Common\Foundation\Interfaces\Constants; class Script extends Minifier { public function ikcgmcycisiccyuc() { $this->name = Constants::qssgasiyswwaciwc; } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\x70\x5f\141\144\x64\x5f\151\156\154\x69\156\145\x5f\x73\143\x72\151\160\164\137\144\141\164\x61", [$this, "\157\x6b\165\x67\165\171\141\143\x67\x67\163\x61\147\145\x71\161"]); parent::kgquecmsgcouyaya(); } public function okuguyacggsageqq($ewgwqamkygiqaawc, string $kqywgoqsmuswammk = null) { return parent::okuguyacggsageqq($ewgwqamkygiqaawc, "\x73\143\x72\x69\160\164"); } public function wamiiiagcwwigucu(?string $ewgwqamkygiqaawc) : ?string { $aksgkeoomwimawms = new JS($ewgwqamkygiqaawc); return $aksgkeoomwimawms->minify(); } }
