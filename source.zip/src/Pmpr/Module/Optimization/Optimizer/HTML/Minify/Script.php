<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb242fc74db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Minify; use MatthiasMullie\Minify\JS; use Pmpr\Common\Foundation\Interfaces\Constants; class Script extends Minifier { public function ikcgmcycisiccyuc() { $this->name = Constants::qssgasiyswwaciwc; } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse("\x77\160\x5f\141\x64\x64\137\151\156\x6c\x69\x6e\x65\x5f\163\143\162\x69\160\164\x5f\144\x61\x74\x61", [$this, "\x6f\153\165\147\x75\171\141\143\x67\147\x73\141\x67\x65\x71\161"]); parent::kgquecmsgcouyaya(); } public function okuguyacggsageqq($ewgwqamkygiqaawc, string $kqywgoqsmuswammk = null) { return parent::okuguyacggsageqq($ewgwqamkygiqaawc, "\x73\x63\162\151\160\x74"); } public function wamiiiagcwwigucu(?string $ewgwqamkygiqaawc) : ?string { $aksgkeoomwimawms = new JS($ewgwqamkygiqaawc); return $aksgkeoomwimawms->minify(); } }
