<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa76d1d04df             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Error; class Error extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto kmikwoqwigwuyqae; } Engine::symcgieuakksimmu(); goto qcuywygiosoqycaa; kmikwoqwigwuyqae: Setting::symcgieuakksimmu(); qcuywygiosoqycaa: } }
