<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a588a282a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Error; class Error extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto goimywgsweeqsewo; } Engine::symcgieuakksimmu(); goto uomwseyiqckeewgo; goimywgsweeqsewo: Setting::symcgieuakksimmu(); uomwseyiqckeewgo: } }
