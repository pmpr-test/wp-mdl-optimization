<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f13d321859c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Optimizer\HTML\Error; class Error extends Common { public function mameiwsayuyquoeq() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto scaimkkukmgoeaya; } Engine::symcgieuakksimmu(); goto ceeqguaoysyaasey; scaimkkukmgoeaya: Setting::symcgieuakksimmu(); ceeqguaoysyaasey: } }
