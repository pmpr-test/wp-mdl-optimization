<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec01cb5e285             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Common\Foundation\Interfaces\Constants; class Manager extends API { public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\x2f\x6f\x70\x74\151\155\151\172\141\x74\151\157\x6e\55\x6d\141\156\x61\147\145\162"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(Constants::aciemiuuwgysykom, $this->eegcqkwceasicmek()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\162\x65\155\x6f\164\145\57\147\145\x74\55\141\160\x70\x73"); if (is_wp_error($sogksuscggsicmac)) { goto sciwggaeogcoesiu; } $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue); sciwggaeogcoesiu: return $sogksuscggsicmac; } }
