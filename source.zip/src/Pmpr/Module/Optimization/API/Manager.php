<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b73d10da1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Common\Foundation\Interfaces\Constants; class Manager extends API { public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\x2f\x6f\160\164\x69\x6d\x69\x7a\x61\164\151\157\x6e\55\155\x61\156\141\147\145\x72"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(Constants::aciemiuuwgysykom, $this->caokeucsksukesyo()->cqusmgskowmesgcg()->ooouaomcuuakuaii()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\162\145\x6d\157\x74\x65\x2f\x67\x65\x74\55\x61\x70\160\x73"); if (!is_wp_error($sogksuscggsicmac)) { $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue); } return $sogksuscggsicmac; } }
