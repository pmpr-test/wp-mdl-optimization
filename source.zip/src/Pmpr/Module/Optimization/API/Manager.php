<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f1c30b6e1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\API; use Pmpr\Common\Foundation\API\API; use Pmpr\Common\Foundation\Interfaces\Constants; class Manager extends API { public function __construct() { $this->domain = $this->saeuwmoyaekkseok("\x2f\157\160\164\151\155\x69\x7a\141\164\151\x6f\x6e\55\155\x61\156\x61\x67\x65\x72"); $this->ueakuaywsqiooygo(40)->iwoewaiwqaisaagy()->kiaqywwoysssqgig(Constants::aciemiuuwgysykom, $this->caokeucsksukesyo()->cqusmgskowmesgcg()->ooouaomcuuakuaii()); parent::__construct(); } public function wskswuomqkmqkkmm() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\162\145\x6d\x6f\x74\x65\57\147\145\164\x2d\141\x70\x70\163"); if (!is_wp_error($sogksuscggsicmac)) { $sogksuscggsicmac = $this->caokeucsksukesyo()->ywqgcuymeiswqyqc()->get($sogksuscggsicmac, Constants::uiwqcumqkgikqyue); } return $sogksuscggsicmac; } }
