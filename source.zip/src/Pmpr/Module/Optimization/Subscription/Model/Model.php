<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1377d8db9a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription\Model; use Pmpr\Module\Optimization\Subscription\Common; class Model extends Common { public function mameiwsayuyquoeq() { Purchase::symcgieuakksimmu(); } }
