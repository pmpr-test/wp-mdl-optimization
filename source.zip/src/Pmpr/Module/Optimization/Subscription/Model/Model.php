<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f27b5b18721             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription\Model; use Pmpr\Module\Optimization\Subscription\Common; class Model extends Common { public function mameiwsayuyquoeq() { Purchase::symcgieuakksimmu(); } }
