<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a8053cce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\x2f\163\165\x62\x73\x63\162\x69\x70\x74\x69\157\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\147\x65\164\55\144\141\x74\x61"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto ugkwqaywmwqucoeo; } $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; ugkwqaywmwqucoeo: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\147\145\x74\x2d\x70\165\162\143\150\x61\x73\x65\x73\x3f\x70\141\x67\x65\75{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto syisomgawcsqeemk; } $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; syisomgawcsqeemk: return $sogksuscggsicmac; } }
