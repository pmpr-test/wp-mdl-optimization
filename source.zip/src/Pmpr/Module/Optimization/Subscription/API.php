<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ec01cb5e285             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\163\165\142\163\x63\x72\151\x70\164\x69\157\156"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\147\x65\x74\55\144\x61\x74\141"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto qmqmskywcgiqgygm; } $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; qmqmskywcgiqgygm: return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x67\x65\164\x2d\x70\165\x72\143\x68\141\x73\145\163\77\x70\x61\x67\x65\x3d{$suaemuyiacqyugsm}"); if (!($sogksuscggsicmac && is_array($sogksuscggsicmac))) { goto ccgsycueagwegqeu; } $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; ccgsycueagwegqeu: return $sogksuscggsicmac; } }
