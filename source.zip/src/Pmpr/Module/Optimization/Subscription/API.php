<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758114e5f226             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\163\165\x62\163\x63\x72\151\160\x74\x69\x6f\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\147\145\164\55\x64\x61\164\141"); if ($sogksuscggsicmac && is_array($sogksuscggsicmac)) { $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; } return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\x2f\147\x65\164\x2d\160\165\162\143\150\x61\163\145\x73\x3f\160\x61\147\x65\x3d{$suaemuyiacqyugsm}"); if ($sogksuscggsicmac && is_array($sogksuscggsicmac)) { $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; } return $sogksuscggsicmac; } }
