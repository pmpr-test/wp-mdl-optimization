<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f9e31abf5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\Subscription; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Module\Optimization\API\Manager; class API extends Manager { public function __construct() { parent::__construct(); $this->domain .= "\57\163\165\142\163\x63\x72\151\160\164\x69\157\x6e"; } public function msyoakwyskammgqi() { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\x67\x65\164\x2d\x64\x61\x74\141"); if ($sogksuscggsicmac && is_array($sogksuscggsicmac)) { $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; } return $sogksuscggsicmac; } public function qqwmsyyqyoeeqsoo($suaemuyiacqyugsm = 1) { $sogksuscggsicmac = $this->eqkieiagqmugguew("\57\147\x65\164\55\160\x75\162\143\x68\141\163\145\x73\77\160\141\x67\145\75{$suaemuyiacqyugsm}"); if ($sogksuscggsicmac && is_array($sogksuscggsicmac)) { $sogksuscggsicmac = $sogksuscggsicmac[Constants::uiwqcumqkgikqyue] ?? []; } return $sogksuscggsicmac; } }
