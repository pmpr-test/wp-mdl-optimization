<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8f0d0713             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\163\163\x65\x74\137\143\x64\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\156\164\145\156\164\x20\104\x65\154\151\x76\x65\x72\x79\x20\116\145\164\167\x6f\x72\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\x64\x61\x70\164\x20\167\151\x74\x68\40\103\x44\x4e\x73", PR__MDL__OPTIMIZATION))); } }
