<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672356236bf3e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver\Setting as JSDeliverSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { JSDeliverSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\x73\x73\x65\164\x5f\x63\144\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\157\156\x74\145\x6e\164\x20\104\145\154\151\166\x65\162\x79\x20\x4e\145\164\167\x6f\162\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\144\x61\x70\x74\40\x77\x69\164\x68\x20\103\x44\116\163", PR__MDL__OPTIMIZATION))); } }
