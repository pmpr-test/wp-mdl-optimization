<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a8053cce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\x73\x73\x65\164\137\143\144\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\156\164\x65\x6e\164\x20\104\x65\x6c\151\166\145\x72\171\40\116\145\x74\x77\157\162\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x41\144\x61\x70\x74\x20\167\151\164\150\x20\103\x44\116\x73", PR__MDL__OPTIMIZATION))); } }
