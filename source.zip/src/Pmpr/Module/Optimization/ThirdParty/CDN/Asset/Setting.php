<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f12a1764bb6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\x73\x73\145\164\x5f\x63\x64\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\x6f\156\164\x65\x6e\x74\x20\x44\x65\x6c\x69\166\145\x72\171\40\116\x65\x74\167\x6f\x72\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\144\x61\x70\164\x20\167\151\x74\150\40\103\104\x4e\163", PR__MDL__OPTIMIZATION))); } }
