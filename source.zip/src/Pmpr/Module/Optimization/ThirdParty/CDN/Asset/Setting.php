<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae19a7b618             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\x61\163\x73\x65\x74\137\x63\x64\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\157\156\x74\145\x6e\164\40\x44\145\x6c\151\x76\145\x72\x79\x20\116\145\164\x77\157\162\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\x61\x70\x74\40\167\151\x74\x68\40\103\104\116\163", PR__MDL__OPTIMIZATION))); } }
