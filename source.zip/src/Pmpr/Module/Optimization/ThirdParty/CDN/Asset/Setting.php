<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758102f55148             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; use Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver\Setting as JSDeliverSetting; class Setting extends SettingSegment { public function mameiwsayuyquoeq() { JSDeliverSetting::symcgieuakksimmu(); } public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\x73\163\145\x74\x5f\x63\144\x6e")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\x6f\x6e\x74\x65\x6e\x74\x20\x44\x65\154\x69\166\145\162\171\x20\x4e\145\164\x77\157\162\x6b", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\x64\x61\160\164\40\167\151\x74\150\x20\103\104\116\163", PR__MDL__OPTIMIZATION))); } }
