<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d840ddfea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\163\163\x65\x74\x5f\143\144\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\103\157\x6e\x74\x65\156\164\x20\104\145\154\x69\x76\x65\x72\x79\40\x4e\145\164\x77\157\x72\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\144\x61\x70\x74\x20\x77\151\x74\x68\x20\103\x44\x4e\163", PR__MDL__OPTIMIZATION))); } }
