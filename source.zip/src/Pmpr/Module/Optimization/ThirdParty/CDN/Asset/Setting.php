<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2b472f16c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSegment; class Setting extends SettingSegment { public function ykwqaukkycogooii() { $this->ogimmkwaymekmoky($this->mkcwgaeaaweamyyg("\141\163\163\145\164\x5f\143\x64\156")->jyumyyugiwwiqomk(30)->saemoowcasogykak(IconInterface::wywqyoieokiocqks)->gswweykyogmsyawy(__("\x43\157\156\164\145\x6e\x74\40\104\145\x6c\151\166\145\162\171\x20\116\x65\x74\167\157\162\153", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\101\144\141\160\164\40\167\151\x74\x68\40\103\104\116\163", PR__MDL__OPTIMIZATION))); } }
