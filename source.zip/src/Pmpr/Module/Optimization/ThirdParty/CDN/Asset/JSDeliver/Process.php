<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e04ea1945             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\152\163\x64\145\154\x69\166\145\162\x5f\141\156\141\x6c\171\172\x65\137\163\x6f\165\162\143\145\x73\x5f\150\x6f\x6f\153"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\x6a\x73\144\145\154\151\x76\145\x72\x5f\x72\x65\155\x6f\x76\145\x5f\157\154\144\x5f\x73\x6f\165\162\x63\145\x73\137\150\x6f\157\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\x73\x64\x65\154\x69\x76\145\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
