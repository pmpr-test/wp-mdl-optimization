<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef50f73aec3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\152\x73\x64\x65\x6c\151\166\145\162\x5f\x61\x6e\x61\154\x79\x7a\x65\x5f\x73\x6f\x75\162\143\145\x73\x5f\150\157\x6f\153"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\152\x73\144\x65\154\x69\x76\145\162\137\x72\145\x6d\157\166\x65\x5f\x6f\x6c\144\137\x73\x6f\165\x72\x63\x65\163\x5f\x68\157\157\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\x73\144\145\154\151\166\x65\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
