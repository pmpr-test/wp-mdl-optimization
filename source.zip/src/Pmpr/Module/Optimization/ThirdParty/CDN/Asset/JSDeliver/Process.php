<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef5003b08f6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\x73\x64\x65\154\151\x76\x65\x72\x5f\141\x6e\141\154\171\x7a\x65\x5f\x73\157\165\x72\x63\x65\x73\137\150\x6f\157\x6b"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\152\x73\144\x65\154\151\x76\x65\x72\x5f\x72\x65\155\157\166\x65\137\157\154\x64\x5f\x73\157\x75\162\x63\145\x73\x5f\x68\157\157\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\x73\144\x65\154\x69\x76\145\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
