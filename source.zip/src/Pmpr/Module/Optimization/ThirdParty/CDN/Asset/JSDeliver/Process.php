<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581596084c7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\163\x64\145\x6c\151\166\x65\x72\137\x61\x6e\x61\x6c\171\x7a\x65\137\x73\157\165\x72\x63\145\163\137\150\157\x6f\153"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\152\163\x64\145\154\x69\x76\145\x72\x5f\x72\145\x6d\157\166\145\137\x6f\154\144\137\163\x6f\x75\x72\143\x65\163\137\x68\157\x6f\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\x73\x64\x65\154\x69\x76\145\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
