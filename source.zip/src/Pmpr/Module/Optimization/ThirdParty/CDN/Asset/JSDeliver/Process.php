<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672356236bf3e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\152\163\144\x65\x6c\151\x76\x65\162\137\x61\x6e\x61\x6c\171\172\145\x5f\163\x6f\x75\x72\143\x65\x73\x5f\150\x6f\x6f\153"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\x6a\x73\x64\x65\x6c\x69\x76\x65\x72\x5f\x72\x65\155\157\166\145\137\x6f\154\x64\137\163\x6f\165\162\x63\x65\x73\137\x68\157\157\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\x73\x64\x65\154\151\166\x65\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
