<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7aea357a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\152\x73\x64\145\154\151\166\145\x72\x5f\x61\x6e\x61\x6c\171\x7a\x65\137\163\x6f\165\x72\x63\x65\163\137\x68\x6f\x6f\153"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\x6a\x73\x64\145\154\151\x76\145\x72\x5f\162\x65\x6d\157\x76\145\137\x6f\x6c\144\x5f\163\157\x75\x72\143\145\x73\137\150\157\x6f\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\x73\144\x65\x6c\151\166\145\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
