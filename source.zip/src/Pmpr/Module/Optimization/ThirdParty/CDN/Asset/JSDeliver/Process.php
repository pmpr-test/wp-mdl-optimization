<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e68d3d663             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\152\163\x64\145\x6c\x69\166\145\162\137\141\156\x61\x6c\171\x7a\145\x5f\163\157\x75\x72\143\x65\163\137\150\x6f\157\153"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\152\x73\x64\x65\154\151\x76\x65\162\x5f\x72\x65\155\x6f\x76\145\x5f\x6f\154\x64\x5f\x73\x6f\x75\x72\143\145\163\137\x68\157\x6f\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\163\x64\x65\154\x69\166\x65\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
