<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec78c96fd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\x73\144\145\x6c\151\166\x65\162\137\x61\156\x61\154\x79\172\145\x5f\163\x6f\165\x72\143\x65\163\x5f\150\157\x6f\153"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\152\163\144\145\x6c\151\x76\145\x72\137\x72\x65\x6d\157\x76\x65\137\x6f\154\x64\x5f\x73\157\165\x72\143\x65\x73\137\150\x6f\157\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\x73\144\x65\154\151\166\145\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
