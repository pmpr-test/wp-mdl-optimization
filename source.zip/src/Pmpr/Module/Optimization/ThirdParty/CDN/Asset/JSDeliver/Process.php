<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e29caf530             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\152\x73\144\145\154\151\x76\x65\x72\137\x61\x6e\x61\154\x79\x7a\x65\x5f\x73\157\x75\162\x63\x65\x73\x5f\150\157\x6f\153"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\152\163\144\145\x6c\x69\x76\x65\162\x5f\162\145\x6d\157\166\145\137\x6f\154\x64\x5f\x73\x6f\x75\x72\x63\x65\x73\137\x68\x6f\x6f\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\x73\x64\x65\154\x69\166\145\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
