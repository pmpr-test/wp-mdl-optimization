<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6758114e5f226             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\x6a\163\144\145\x6c\x69\x76\x65\162\137\141\156\x61\x6c\171\172\145\137\x73\x6f\165\162\143\145\163\x5f\x68\x6f\157\x6b"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\152\x73\144\145\x6c\x69\166\145\162\137\162\145\155\x6f\x76\x65\x5f\157\x6c\x64\137\163\x6f\165\x72\x63\x65\x73\137\150\x6f\157\153"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\x6a\163\x64\x65\154\151\x76\x65\x72"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
