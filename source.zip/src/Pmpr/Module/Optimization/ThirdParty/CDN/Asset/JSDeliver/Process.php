<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f18c2e9c9db             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Module\Optimization\Optimization; use Pmpr\Module\Optimization\Queue; class Process extends Queue { const ANALYZE = Optimization::kgswyesggeyekgmg . "\152\x73\x64\x65\154\x69\166\145\162\137\141\156\141\x6c\171\x7a\145\137\163\157\x75\162\143\145\x73\x5f\x68\x6f\157\x6b"; const akguikecmoggsykg = Optimization::kgswyesggeyekgmg . "\x6a\x73\144\145\154\151\166\145\162\137\x72\x65\155\x6f\166\145\137\x6f\x6c\144\x5f\x73\157\x75\x72\x63\x65\163\137\150\x6f\x6f\x6b"; public function ikcgmcycisiccyuc() { parent::ikcgmcycisiccyuc(); $this->group .= "\152\163\144\145\x6c\x69\166\145\162"; } public function cywkaeaiwmweciui() : int { return $this->ooosmymooksgmyos(time(), MINUTE_IN_SECONDS * 30, self::ANALYZE); } public function mciwicaywiwmccoc() : int { return $this->ooosmymooksgmyos(time(), DAY_IN_SECONDS, self::akguikecmoggsykg); } }
