<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e29caf530             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\142\x6c\145\137\152\163\144\x65\154\x69\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\x65\164\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\145\x6c\151\x76\145\162\x5f\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\145\154\151\x76\145\162\40\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\x62\154\x65\40\x46\157\x72\40\x41\163\163\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\x63\153\40\164\150\x69\163\x20\157\x70\x74\151\x6f\x6e\40\164\157\40\162\145\x70\154\141\143\145\40\162\145\x73\157\x75\162\143\145\x73\40\x62\171\40\112\x53\104\x65\154\151\166\x65\162\x20\x63\144\156\56", PR__MDL__OPTIMIZATION)))); } }
