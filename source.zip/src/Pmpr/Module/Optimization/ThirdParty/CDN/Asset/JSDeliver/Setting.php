<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1d840ddfea             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\x62\154\x65\137\x6a\x73\144\x65\154\x69\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\163\x65\164\137\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\144\x65\154\151\x76\x65\162\x5f\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\104\145\x6c\x69\x76\145\162\40\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\x62\x6c\145\x20\106\157\162\x20\x41\x73\x73\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\145\x63\x6b\40\164\x68\x69\163\40\157\x70\x74\x69\x6f\156\x20\x74\x6f\40\x72\145\160\154\141\143\145\40\162\145\163\x6f\165\162\x63\x65\x73\x20\x62\x79\x20\x4a\123\x44\145\154\x69\x76\x65\162\x20\143\144\156\56", PR__MDL__OPTIMIZATION)))); } }
