<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             672f20b994df3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\x62\154\145\x5f\152\x73\x64\145\x6c\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\x65\x74\x5f\x63\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\x65\x6c\151\x76\145\162\x5f\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\x65\x6c\151\x76\x65\x72\x20\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\142\154\x65\x20\106\x6f\162\40\101\163\x73\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\x63\x6b\x20\x74\150\x69\x73\40\157\160\x74\x69\x6f\156\40\x74\157\40\162\x65\160\x6c\141\143\145\x20\x72\x65\x73\x6f\x75\162\x63\x65\163\40\142\171\x20\x4a\123\104\x65\154\151\x76\145\162\x20\x63\144\156\56", PR__MDL__OPTIMIZATION)))); } }
