<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67581d1ae35f7             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\x61\142\154\145\137\x6a\163\144\x65\154\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\163\145\164\x5f\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\145\154\151\x76\x65\x72\137\x63\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\145\154\x69\166\x65\162\40\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\142\154\x65\x20\x46\x6f\162\x20\x41\163\x73\x65\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\x65\143\x6b\40\x74\150\151\x73\40\157\x70\x74\151\157\156\40\x74\157\40\162\x65\x70\154\x61\143\145\x20\x72\x65\x73\157\165\162\x63\145\x73\40\x62\171\40\x4a\123\x44\x65\x6c\x69\x76\x65\x72\40\x63\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
