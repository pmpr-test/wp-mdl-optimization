<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e04ea1945             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\x62\x6c\145\x5f\152\163\144\145\154\x69\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\x65\x74\137\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\x65\154\151\166\145\x72\x5f\143\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\x44\145\154\151\166\145\162\40\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\x62\x6c\145\40\106\157\x72\x20\101\x73\x73\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\143\x6b\x20\x74\150\151\x73\x20\x6f\x70\x74\151\x6f\156\x20\x74\157\40\x72\x65\x70\154\141\x63\x65\x20\162\x65\x73\157\165\162\143\145\x73\40\142\171\40\112\123\104\145\154\151\x76\145\162\x20\143\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
