<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb16c082ce5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\x62\154\145\x5f\152\163\144\145\x6c\x69\x76\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\163\145\x74\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\145\x6c\x69\x76\x65\162\x5f\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\x65\154\151\x76\x65\162\40\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\141\x62\154\145\40\x46\157\162\40\x41\163\x73\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\x65\143\x6b\40\164\x68\x69\x73\x20\x6f\x70\164\151\x6f\x6e\40\x74\x6f\40\x72\145\160\154\141\143\x65\x20\x72\x65\x73\x6f\x75\x72\x63\x65\163\x20\142\171\x20\112\x53\x44\145\x6c\x69\x76\x65\162\40\143\x64\x6e\56", PR__MDL__OPTIMIZATION)))); } }
