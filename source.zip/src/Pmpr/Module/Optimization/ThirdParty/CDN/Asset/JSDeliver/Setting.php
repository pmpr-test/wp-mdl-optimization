<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0d3a1360b4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\142\154\145\137\152\163\144\145\x6c\x69\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\x65\164\x5f\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\145\x6c\x69\x76\x65\162\137\143\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\145\x6c\x69\166\x65\162\40\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\142\x6c\x65\40\106\x6f\x72\40\101\163\x73\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\x63\x6b\x20\x74\x68\151\x73\40\157\x70\x74\151\157\156\40\164\157\x20\162\145\160\154\141\143\x65\40\x72\145\163\157\x75\162\143\145\x73\x20\x62\x79\x20\112\123\x44\x65\x6c\x69\x76\x65\x72\x20\143\144\156\56", PR__MDL__OPTIMIZATION)))); } }
