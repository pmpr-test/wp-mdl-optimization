<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d980cb95de             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\142\x6c\145\137\152\163\x64\x65\154\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\x65\x74\x5f\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\x65\154\x69\166\x65\162\x5f\x63\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\x44\x65\154\x69\166\x65\162\x20\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\x62\154\145\40\x46\157\162\40\101\x73\x73\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\x6b\x20\x74\x68\x69\163\x20\157\160\164\x69\157\156\x20\164\x6f\40\x72\x65\160\154\x61\143\x65\x20\162\x65\163\157\x75\162\x63\x65\163\x20\x62\171\40\x4a\123\x44\x65\x6c\x69\x76\145\x72\40\143\144\156\56", PR__MDL__OPTIMIZATION)))); } }
