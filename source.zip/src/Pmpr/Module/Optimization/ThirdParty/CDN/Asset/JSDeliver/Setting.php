<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1377d8db9a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\142\x6c\x65\137\152\163\x64\x65\154\x69\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\145\x74\x5f\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\x65\x6c\x69\x76\145\162\x5f\143\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\104\145\x6c\151\166\x65\162\x20\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\142\x6c\x65\40\x46\157\162\x20\101\163\x73\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\x6b\x20\164\x68\x69\163\x20\157\160\x74\151\x6f\x6e\x20\164\x6f\x20\162\x65\160\x6c\141\143\145\40\x72\145\x73\157\165\x72\143\145\163\40\142\x79\x20\x4a\123\x44\145\154\x69\166\x65\x72\40\x63\x64\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
