<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f431078326f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\141\142\x6c\145\137\152\x73\x64\x65\154\x69\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\x65\164\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\x65\x6c\151\x76\x65\162\x5f\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\104\x65\x6c\x69\166\145\162\40\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\x62\154\145\x20\x46\157\x72\40\101\x73\163\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\143\153\40\x74\x68\151\x73\40\x6f\160\x74\x69\157\156\40\164\157\x20\162\x65\160\154\141\x63\145\x20\162\145\x73\157\x75\162\x63\x65\163\40\142\x79\x20\112\123\104\x65\154\151\x76\x65\162\x20\143\x64\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
