<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec78c96fd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\x62\154\x65\137\x6a\x73\x64\x65\x6c\151\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\163\145\164\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\145\x6c\x69\166\x65\162\137\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\x44\x65\x6c\x69\166\145\162\x20\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\142\154\145\x20\106\157\162\x20\101\163\x73\x65\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\x6b\40\164\150\151\x73\x20\157\x70\164\x69\157\156\40\164\x6f\40\x72\145\160\x6c\x61\x63\145\40\x72\145\x73\157\x75\x72\143\x65\x73\40\142\x79\x20\x4a\x53\104\x65\x6c\x69\166\x65\x72\40\x63\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
