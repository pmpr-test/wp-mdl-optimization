<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f13d321859c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\x62\x6c\145\137\x6a\163\x64\145\x6c\x69\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\145\x74\x5f\x63\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\145\x6c\151\x76\145\162\x5f\143\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\145\x6c\151\x76\x65\162\40\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\141\x62\154\145\x20\106\x6f\x72\40\101\163\x73\x65\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\143\x6b\40\x74\x68\x69\163\40\x6f\x70\164\151\157\156\x20\164\157\x20\x72\145\x70\x6c\141\x63\145\x20\162\145\x73\x6f\165\x72\143\145\x73\x20\142\x79\x20\112\x53\x44\145\154\x69\166\x65\x72\x20\143\x64\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
