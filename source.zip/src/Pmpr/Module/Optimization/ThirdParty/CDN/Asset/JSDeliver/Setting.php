<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e823d067d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\x61\142\154\145\x5f\152\163\144\145\x6c\151\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\145\x74\137\143\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\144\145\154\x69\166\145\162\137\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\145\x6c\151\166\145\162\40\x43\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\x62\154\x65\40\x46\157\x72\40\x41\x73\163\x65\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\143\x6b\40\x74\150\151\163\x20\x6f\160\x74\151\157\x6e\40\x74\x6f\x20\x72\145\x70\154\141\x63\x65\x20\162\145\x73\x6f\x75\162\143\145\x73\x20\142\171\40\112\123\104\x65\154\x69\166\x65\x72\x20\143\144\156\56", PR__MDL__OPTIMIZATION)))); } }
