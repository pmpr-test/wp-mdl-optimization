<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae19a7b618             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\x62\154\145\x5f\152\x73\x64\145\x6c\151\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\x65\164\137\x63\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\144\145\x6c\151\x76\145\x72\137\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\x44\145\154\151\166\x65\x72\40\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\156\x61\142\154\145\40\x46\157\162\40\x41\x73\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\145\143\x6b\x20\164\x68\x69\163\40\x6f\x70\x74\151\157\x6e\x20\164\157\40\x72\x65\160\154\x61\x63\x65\x20\162\145\x73\x6f\x75\x72\x63\x65\x73\x20\142\171\40\x4a\x53\x44\x65\x6c\151\166\145\x72\40\143\x64\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
