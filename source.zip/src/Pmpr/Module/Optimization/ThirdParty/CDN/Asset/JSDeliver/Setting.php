<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f2a588a282a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\x62\154\x65\137\x6a\x73\144\145\x6c\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\141\x73\x73\x65\164\137\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\145\154\151\166\145\162\x5f\143\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\145\154\151\x76\x65\x72\40\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\142\x6c\145\40\x46\x6f\162\40\101\163\x73\145\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\x6b\x20\164\150\151\163\x20\x6f\x70\x74\x69\x6f\x6e\40\x74\x6f\x20\x72\x65\160\x6c\141\143\x65\40\162\145\163\157\x75\162\143\145\163\40\x62\171\x20\112\123\x44\x65\154\151\166\145\x72\x20\x63\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
