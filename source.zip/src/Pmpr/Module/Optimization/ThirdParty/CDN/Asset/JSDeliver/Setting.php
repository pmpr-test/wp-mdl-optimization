<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef5003b08f6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\142\154\x65\x5f\x6a\163\x64\x65\154\x69\x76\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\145\164\x5f\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\145\154\151\x76\145\x72\x5f\143\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\x65\154\x69\x76\145\x72\40\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\156\x61\x62\154\145\40\106\157\x72\x20\101\x73\163\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\143\153\x20\164\150\x69\x73\x20\x6f\x70\164\x69\x6f\x6e\x20\x74\157\x20\162\x65\x70\x6c\x61\143\145\40\x72\145\163\x6f\x75\162\143\x65\163\40\142\x79\40\112\x53\x44\145\154\151\166\145\162\x20\143\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
