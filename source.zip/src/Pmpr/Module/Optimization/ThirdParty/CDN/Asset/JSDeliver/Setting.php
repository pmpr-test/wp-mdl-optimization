<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f1e68d3d663             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\x61\x62\154\145\137\x6a\163\144\x65\x6c\x69\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\145\x74\137\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\x65\x6c\151\166\x65\162\137\x63\x64\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\145\x6c\x69\x76\x65\x72\40\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\141\x62\x6c\145\40\106\157\162\40\x41\163\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\x65\143\153\x20\x74\150\151\163\40\x6f\x70\164\151\x6f\x6e\x20\x74\x6f\x20\162\145\x70\154\x61\143\145\40\x72\145\x73\x6f\x75\162\x63\145\163\x20\142\171\40\x4a\x53\x44\x65\154\151\x76\x65\x72\40\x63\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
