<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb25af783f1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\x61\x62\x6c\x65\x5f\152\163\x64\145\154\x69\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\x65\164\x5f\143\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\144\x65\154\x69\x76\x65\162\137\143\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\x65\x6c\151\166\x65\x72\40\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\142\154\145\x20\106\x6f\162\x20\101\163\163\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\x65\x63\x6b\x20\164\x68\x69\x73\x20\157\160\x74\151\x6f\x6e\40\x74\x6f\x20\x72\x65\x70\x6c\141\x63\145\40\x72\145\163\157\x75\162\x63\145\163\x20\142\x79\40\112\x53\x44\145\154\151\166\145\162\x20\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
