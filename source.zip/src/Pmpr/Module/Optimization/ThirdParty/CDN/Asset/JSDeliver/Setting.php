<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7aea357a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\x62\154\145\137\x6a\x73\x64\x65\x6c\x69\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\x65\164\x5f\x63\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\x64\145\154\151\166\145\x72\137\143\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\x44\x65\x6c\151\166\x65\x72\40\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\142\154\145\x20\106\x6f\x72\x20\101\163\163\x65\x74\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\143\x6b\40\x74\x68\x69\x73\x20\x6f\160\x74\151\x6f\156\x20\164\x6f\40\x72\145\160\x6c\x61\143\145\40\x72\145\163\x6f\165\x72\143\x65\163\40\x62\171\40\112\123\x44\x65\x6c\x69\x76\145\162\40\x63\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
