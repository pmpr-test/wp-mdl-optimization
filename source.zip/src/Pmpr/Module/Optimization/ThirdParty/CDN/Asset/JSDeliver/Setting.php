<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eb16d680906             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\142\154\145\x5f\152\x73\x64\x65\x6c\151\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\145\x74\x5f\143\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\x64\x65\x6c\151\x76\x65\x72\x5f\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\x65\154\x69\166\145\162\40\x43\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\142\154\145\40\x46\157\x72\40\101\x73\x73\x65\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\x65\143\153\x20\164\x68\x69\163\40\x6f\160\x74\151\x6f\156\x20\164\157\x20\162\x65\160\x6c\141\x63\x65\40\162\145\x73\x6f\165\x72\x63\145\x73\40\x62\171\40\112\123\x44\145\154\x69\x76\x65\162\x20\x63\144\x6e\x2e", PR__MDL__OPTIMIZATION)))); } }
