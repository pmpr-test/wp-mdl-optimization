<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77c48a139             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\141\x62\x6c\x65\x5f\x6a\163\x64\x65\154\x69\166\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\141\163\x73\145\164\137\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\144\145\x6c\x69\x76\x65\x72\137\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\x53\104\x65\154\x69\166\145\162\x20\103\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\142\x6c\x65\x20\106\x6f\x72\x20\101\x73\x73\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\150\145\143\153\40\164\150\x69\x73\40\x6f\160\x74\151\157\156\x20\164\x6f\40\x72\145\x70\154\141\143\145\x20\162\x65\163\x6f\165\x72\x63\145\x73\x20\142\171\x20\112\123\104\x65\154\x69\166\145\x72\x20\143\x64\156\x2e", PR__MDL__OPTIMIZATION)))); } }
