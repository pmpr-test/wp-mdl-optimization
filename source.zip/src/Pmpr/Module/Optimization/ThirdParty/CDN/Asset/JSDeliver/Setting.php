<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f16a50f1e99             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\156\x61\x62\x6c\x65\137\x6a\x73\144\x65\x6c\x69\166\145\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\163\145\x74\137\143\x64\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\x73\144\145\154\x69\x76\145\162\x5f\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\123\104\x65\154\x69\x76\x65\x72\x20\103\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\x61\142\x6c\x65\x20\x46\157\162\x20\101\x73\163\x65\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\x65\143\x6b\40\x74\150\151\x73\x20\x6f\x70\x74\151\157\x6e\40\164\x6f\40\x72\x65\x70\154\x61\x63\145\x20\x72\x65\163\157\x75\x72\x63\145\x73\40\x62\171\40\112\x53\x44\x65\x6c\x69\166\145\x72\40\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
