<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             688a1f25f2744             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = 'enable_jsdeliver'; public function ikcgmcycisiccyuc() { $this->segment = 'asset_cdn'; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->kwkugmqouisgkqig($uuyucgkyusckoaeq->ycgeeoiieoiakgam('jsdeliver_cdn')->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__('JSDeliver CDN', PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($uuyucgkyusckoaeq->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__('Enable For Assets', PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__('Check this option to replace resources by JSDeliver cdn.', PR__MDL__OPTIMIZATION)))); } }
