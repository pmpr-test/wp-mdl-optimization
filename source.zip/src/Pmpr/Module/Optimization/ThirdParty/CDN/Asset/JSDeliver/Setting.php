<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ef50f73aec3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\156\x61\142\x6c\x65\x5f\x6a\163\x64\145\x6c\151\166\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\163\x73\145\164\137\x63\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\163\x64\145\x6c\x69\166\x65\162\137\143\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\x44\x65\x6c\x69\x76\145\162\x20\x43\x44\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\x62\154\145\40\x46\157\162\x20\x41\163\163\145\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\153\x20\x74\x68\x69\163\40\x6f\160\164\x69\x6f\156\40\x74\157\x20\162\145\160\154\x61\143\145\40\162\x65\x73\x6f\x75\162\x63\x65\163\x20\x62\171\x20\112\x53\104\145\x6c\x69\x76\145\162\40\143\144\156\56", PR__MDL__OPTIMIZATION)))); } }
