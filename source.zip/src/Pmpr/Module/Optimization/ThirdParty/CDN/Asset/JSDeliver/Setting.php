<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc08864f41             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\x65\x6e\141\142\154\145\x5f\x6a\x73\144\x65\x6c\151\166\145\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\x65\164\x5f\x63\144\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\152\163\144\145\154\151\166\x65\x72\x5f\x63\x64\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\x4a\123\104\145\x6c\x69\x76\145\162\40\103\104\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\x62\x6c\x65\x20\106\157\x72\40\x41\x73\x73\145\164\163", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\x68\145\x63\153\x20\164\150\151\163\x20\157\x70\x74\x69\157\156\x20\164\157\x20\x72\x65\x70\x6c\x61\143\x65\x20\162\145\x73\x6f\x75\162\143\x65\163\40\142\171\x20\x4a\123\104\145\154\151\x76\145\162\x20\x63\144\x6e\56", PR__MDL__OPTIMIZATION)))); } }
