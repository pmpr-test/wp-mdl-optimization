<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ebf66918980             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\141\142\154\x65\137\x6a\x73\x64\145\x6c\x69\x76\x65\x72"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\x65\164\137\x63\144\156"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\144\145\x6c\x69\166\x65\x72\137\143\144\156")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\x65\154\x69\166\x65\x72\40\x43\x44\x4e", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\x45\x6e\141\x62\154\145\40\x46\x6f\162\40\101\163\x73\x65\164\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\x43\150\x65\143\153\40\x74\150\151\163\40\x6f\160\x74\x69\x6f\x6e\40\x74\157\x20\162\145\160\x6c\x61\143\x65\40\x72\x65\x73\x6f\x75\x72\x63\145\163\40\142\171\x20\112\x53\104\x65\x6c\151\166\145\x72\x20\x63\144\156\56", PR__MDL__OPTIMIZATION)))); } }
