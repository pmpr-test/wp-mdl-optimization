<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd9008d45             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Asset\JSDeliver; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Optimization\Setting\SettingSection; class Setting extends SettingSection { const kieuqsgucmomsqey = "\145\x6e\x61\142\x6c\x65\x5f\152\163\x64\x65\154\151\x76\x65\162"; public function ikcgmcycisiccyuc() { $this->segment = "\x61\x73\x73\145\164\x5f\143\x64\x6e"; parent::ikcgmcycisiccyuc(); } public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x6a\x73\x64\145\x6c\x69\166\x65\162\137\x63\144\x6e")->saemoowcasogykak(IconInterface::qigccqqwyyymgkuk)->gswweykyogmsyawy(__("\112\x53\104\x65\154\151\x76\x65\x72\x20\103\104\116", PR__MDL__OPTIMIZATION))->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::kieuqsgucmomsqey)->gswweykyogmsyawy(__("\105\x6e\x61\x62\x6c\x65\40\106\x6f\x72\40\x41\x73\x73\x65\x74\x73", PR__MDL__OPTIMIZATION))->gucwmccyimoagwcm(__("\103\x68\x65\143\153\40\164\x68\x69\163\x20\x6f\x70\x74\x69\x6f\x6e\40\164\x6f\x20\162\145\x70\154\x61\x63\x65\x20\162\145\x73\x6f\165\162\x63\x65\163\40\142\171\40\x4a\123\104\145\x6c\x69\x76\x65\x72\x20\143\x64\156\56", PR__MDL__OPTIMIZATION)))); } }
