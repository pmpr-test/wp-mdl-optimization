<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705177f65977             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty\CDN\Cloudflare; use Pmpr\Module\Optimization\ThirdParty\CDN\Common as BaseClass; abstract class Common extends BaseClass { private ?Engine $engine = null; public function uykissogmuaaocsg() : Engine { if ($this->engine) { goto ssmgmiuqoeiuacsa; } $this->engine = Engine::symcgieuakksimmu(); ssmgmiuqoeiuacsa: return $this->engine; } public function yusooeuwemoqcwmm() : bool { return $this->weysguygiseoukqw(Setting::kwuagsmkgsoqgqqi) && $this->weysguygiseoukqw(Setting::iqksqseqeqmaukkk); } public function qoyqoeoicgmuskoc() : bool { return (bool) $this->weysguygiseoukqw(Setting::amkasseuucsemuqm); } }
