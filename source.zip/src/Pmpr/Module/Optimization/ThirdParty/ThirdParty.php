<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fa77c48a139             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Optimization\ThirdParty; use Pmpr\Module\Optimization\ThirdParty\CDN\CDN; class ThirdParty extends Common { public function mameiwsayuyquoeq() { CDN::symcgieuakksimmu(); } }
